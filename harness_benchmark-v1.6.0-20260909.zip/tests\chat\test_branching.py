"""Tests for dhc.services.session_manager branching (v1.5.0, ADR-0019).

10 tests covering:

1. Linear history is preserved (parent_id chains to the previous message).
2. Old session files (no `parent_id`, no `active_tip_id`) load with
   fields backfilled.
3. Branch from a middle message creates a fork.
4. `active_tip_id` advances to the new message.
5. `branch_switch` changes the active tip; refused during a stream.
6. `list_branches` returns the tips with their reconstructed paths.
7. `reconstruct_path` walks leaf → root and reverses the list.
8. `BranchDepthExceeded` is raised for a cycle / tampered parent_id.
9. `branch_switch` returns None for an unknown leaf.
10. `usage_totals` is branch-agnostic (sum across all messages).
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from dhc.services.session_manager import (
    BRANCH_MAX_DEPTH,
    BranchDepthExceeded,
    SessionManager,
)


@pytest.fixture
def mgr(tmp_path: Path) -> SessionManager:
    return SessionManager(tmp_path)


# ---------- 1. Linear history ----------


def test_linear_history_chains_parent_id(mgr: SessionManager) -> None:
    """Linear chat: each message's parent_id is the previous message."""
    s = mgr.create()
    m1 = mgr.append_message(s.id, "user", "Hello")
    m2 = mgr.append_message(s.id, "assistant", "Hi there")
    m3 = mgr.append_message(s.id, "user", "How are you?")
    # m1 is the root, m2's parent is m1, m3's parent is m2.
    assert m1["parent_id"] is None
    assert m2["parent_id"] == m1["id"]
    assert m3["parent_id"] == m2["id"]
    # active_tip_id advances to the latest message.
    assert s.active_tip_id == m3["id"]


# ---------- 2. Old session files backfill ----------


def test_old_session_file_backfills_fields(tmp_path: Path) -> None:
    """A session file written by v1.4.0 (no parent_id, no active_tip_id)
    loads with both fields backfilled.
    """
    from dhc.services.session_manager import Session
    raw = {
        "id": "s_legacy0000000001",
        "title": "old",
        "created_at": 0,
        "updated_at": 0,
        "messages": [
            {"id": "m_legacy0001", "role": "user", "content": "a", "ts_ms": 0},
            {"id": "m_legacy0002", "role": "assistant", "content": "b", "ts_ms": 0},
        ],
        "model": "",
        "tags": [],
        "pinned": False,
        "archived": False,
        "usage_totals": {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
            "last_turn_prompt": 0,
            "last_turn_completion": 0,
        },
        # No active_tip_id, no parent_id on messages.
    }
    # The session file goes into `tmp_path/sessions/{id}.json`
    # (the manager's expected layout, see `SessionManager._dir`).
    sessions_dir = tmp_path / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    path = sessions_dir / "s_legacy0000000001.json"
    path.write_text(json.dumps(raw), encoding="utf-8")
    # v1.5.1.2 (audit hotfix): `SessionManager` takes the parent;
    # `_dir` = parent / "sessions". The previous convention of
    # pre-creating `tmp_path / "sessions"` and passing that as the
    # parent produced the doubled `tmp_path/sessions/sessions/`
    # layout; the parent should be `tmp_path` directly.
    mgr = SessionManager(tmp_path)
    s = mgr.get("s_legacy0000000001")
    assert s is not None
    # parent_id is backfilled: first message None, second is the first.
    assert s.messages[0]["parent_id"] is None
    assert s.messages[1]["parent_id"] == "m_legacy0001"
    # active_tip_id is the last message's id.
    assert s.active_tip_id == "m_legacy0002"


# ---------- 3. Branch from middle ----------


def test_branch_from_middle_creates_fork(mgr: SessionManager) -> None:
    """A `branch_create` from a middle message forks the conversation."""
    s = mgr.create()
    m1 = mgr.append_message(s.id, "user", "Hello")
    m2 = mgr.append_message(s.id, "assistant", "Hi")
    m3 = mgr.append_message(s.id, "user", "Tell me about X")
    # Fork from m1.
    f1 = mgr.branch_create(s.id, m1["id"], "user", "What about Y?")
    assert f1 is not None
    assert f1["parent_id"] == m1["id"]
    # f1 is the new tip; the old tip (m3) is preserved as a leaf.
    assert s.active_tip_id == f1["id"]


# ---------- 4. active_tip_id advances ----------


def test_active_tip_id_advances(mgr: SessionManager) -> None:
    """`append_message` always advances active_tip_id to the new message."""
    s = mgr.create()
    assert s.active_tip_id is None
    m1 = mgr.append_message(s.id, "user", "a")
    assert s.active_tip_id == m1["id"]
    m2 = mgr.append_message(s.id, "assistant", "b")
    assert s.active_tip_id == m2["id"]


# ---------- 5. branch_switch + stream guard ----------


def test_branch_switch_changes_active_tip(mgr: SessionManager) -> None:
    """`branch_switch` updates the active tip; refused during a stream."""
    s = mgr.create()
    m1 = mgr.append_message(s.id, "user", "a")
    m2 = mgr.append_message(s.id, "assistant", "b")
    m3 = mgr.append_message(s.id, "user", "c")
    # Switch to m1.
    s2 = mgr.branch_switch(s.id, m1["id"])
    assert s2 is not None
    assert s2.active_tip_id == m1["id"]
    # Stream in progress: switch refused.
    mgr.begin_stream(s.id)
    refused = mgr.branch_switch(s.id, m2["id"])
    assert refused is None
    mgr.end_stream(s.id)
    # After stream: switch succeeds.
    ok = mgr.branch_switch(s.id, m2["id"])
    assert ok is not None
    assert ok.active_tip_id == m2["id"]


# ---------- 6. list_branches ----------


def test_list_branches_returns_tips_with_paths(mgr: SessionManager) -> None:
    """`list_branches` returns one entry per tip with the reconstructed
    path from the root to the tip.
    """
    s = mgr.create()
    m1 = mgr.append_message(s.id, "user", "root")
    m2 = mgr.append_message(s.id, "assistant", "a")
    m3 = mgr.branch_create(s.id, m1["id"], "user", "b")
    m4 = mgr.append_message(s.id, "assistant", "b-reply")
    # m2 is a tip; m4 is a tip.
    branches = mgr.list_branches(s.id)
    tip_ids = {b["id"] for b in branches}
    assert tip_ids == {m2["id"], m4["id"]}
    # The active branch is m4.
    actives = [b for b in branches if b["active"]]
    assert len(actives) == 1
    assert actives[0]["id"] == m4["id"]


# ---------- 7. reconstruct_path ----------


def test_reconstruct_path_walks_to_root(mgr: SessionManager) -> None:
    """`reconstruct_path` walks leaf → root and returns root first."""
    s = mgr.create()
    m1 = mgr.append_message(s.id, "user", "root")
    m2 = mgr.append_message(s.id, "assistant", "a")
    m3 = mgr.branch_create(s.id, m1["id"], "user", "fork")
    m4 = mgr.append_message(s.id, "assistant", "fork-reply")
    # Path to m4: [m1, m3, m4]
    path = mgr.reconstruct_path(s.id, m4["id"])
    assert [m["id"] for m in path] == [m1["id"], m3["id"], m4["id"]]


# ---------- 8. BranchDepthExceeded ----------


def test_branch_depth_guard(mgr: SessionManager, monkeypatch) -> None:
    """A cycle in the parent_id chain raises BranchDepthExceeded."""
    # Build a small session and then poison the parent_id chain.
    s = mgr.create()
    m1 = mgr.append_message(s.id, "user", "a")
    m2 = mgr.append_message(s.id, "assistant", "b")
    # Poison: m2's parent_id points to itself.
    s.messages[-1]["parent_id"] = m2["id"]
    with pytest.raises(BranchDepthExceeded):
        mgr.reconstruct_path(s.id, m2["id"])


# ---------- 9. branch_switch with unknown leaf ----------


def test_branch_switch_unknown_leaf_returns_none(mgr: SessionManager) -> None:
    """`branch_switch` with an unknown leaf id returns None."""
    s = mgr.create()
    mgr.append_message(s.id, "user", "a")
    result = mgr.branch_switch(s.id, "m_nonexistent")
    assert result is None


# ---------- 10. usage_totals is branch-agnostic ----------


def test_usage_totals_branch_agnostic(mgr: SessionManager) -> None:
    """`usage_totals` sums across all messages regardless of branch.

    Branching does not partition the totals: the session's
    `usage_totals` is a flat token bucket.
    """
    s = mgr.create()
    m1 = mgr.append_message(
        s.id, "assistant", "x", tokens={"prompt": 5, "completion": 7}
    )
    m2 = mgr.append_message(
        s.id, "assistant", "y", tokens={"prompt": 3, "completion": 4}
    )
    mgr.update(
        s.id,
        usage_totals={
            "prompt_tokens": 5 + 3,
            "completion_tokens": 7 + 4,
            "total_tokens": (5 + 3) + (7 + 4),
            "last_turn_prompt": 3,
            "last_turn_completion": 4,
        },
    )
    # Fork from m1; new messages don't reset the totals.
    f1 = mgr.branch_create(s.id, m1["id"], "assistant", "z", auto_title=False)
    assert f1 is not None
    # Reload the session.
    s2 = mgr.get(s.id)
    assert s2 is not None
    # Totals are still 8 / 11 / 19.
    assert s2.usage_totals["prompt_tokens"] == 8
    assert s2.usage_totals["completion_tokens"] == 11
    assert s2.usage_totals["total_tokens"] == 19
