"""Tests for dhc.cordis.secrets v0x03 name binding (ADR-0013).

v1.3.3 binds the secret name into the v0x03 MAC input. A valid v0x03
envelope stored under a different name fails the tag check on read,
which closes the confused-deputy attack where an attacker with write
access to the secrets log could swap the name of a valid envelope and
cause the application to use the wrong key against a provider.

Wire format is unchanged. The tag is computed over
`header || ext_area || nonce || name || ct` for v0x03 envelopes.
v0x01 and v0x02 envelopes do not bind the name; their tags pre-date
this property.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from dhc.cordis.secrets import (
    HEADER_V1,
    HEADER_V2,
    HEADER_V3,
    HEADER_V4,
    NONCE_LEN,
    SecretEnvelopeError,
    SecretsService,
    STRICT_NONCE_LEN,
    TAG_LEN,
    _seal_with,
    open_envelope,
    seal,
)


MASTER = b"k" * 32


# ---------- 1. v0x03 + AAD name-binding round-trip preserves plaintext ----------


def test_v03_aad_roundtrip_preserves_plaintext():
    """seal(name=A) → open(name=A) returns the original plaintext
    for the v0x03 envelope, including at HMAC block boundaries."""
    for n in [0, 1, 15, 16, 17, 31, 32, 33, 100, 1024, 65536]:
        pt = bytes((i * 7 + 3) & 0xFF for i in range(n))
        # Pin to v0x03 explicitly; the public seal() defaults to v0x04
        # since v1.3.4 (ADR-0014).
        env = _seal_with(pt, MASTER, HEADER_V3, name=b"alpha")
        assert env[:4] == HEADER_V3
        assert open_envelope(env, MASTER, name=b"alpha") == pt


# ---------- 2. v0x03 sealed with name=A opens with name=A ----------


def test_v03_seal_with_name_a_opens_with_name_a():
    """Lighter version of test 1: the common path where the same
    name is supplied on both sides. The plaintext is recovered."""
    env = _seal_with(b"shared secret", MASTER, HEADER_V3, name=b"shared")
    assert open_envelope(env, MASTER, name=b"shared") == b"shared secret"


# ---------- 3. Confused-deputy test: name swap raises ----------


def test_confused_deputy_name_swap_raises():
    """A v0x03 envelope sealed for name=A must fail to open when
    the reader is told the name is B. This is the headline test
    for ADR-0013; it closes the confused-deputy attack where an
    attacker with write access to the secrets log swaps the
    name of a valid envelope.

    The error message is intentionally ambiguous ('authentication
    failed') to avoid leaking which side of the binding the
    attacker tampered with.
    """
    env = _seal_with(b"sk-openai-1234567890", MASTER, HEADER_V3, name=b"openai_gpt4o")
    with pytest.raises(SecretEnvelopeError) as excinfo:
        open_envelope(env, MASTER, name=b"anthropic_claude3")
    assert "authentication failed" in str(excinfo.value)


# ---------- 4. v0x03 open without name raises unless require_binding=False ----------


def test_v03_open_without_name_raises_unless_require_binding_false():
    """v0x03 envelopes require a name to be bound. Reading a v0x03
    envelope without a name (and the default require_binding=True)
    raises. Migration scripts can opt out via require_binding=False
    on the read side AND must seal with name=b"" on the write side
    (otherwise the open side will not match the seal side).
    """
    # The public seal() requires a name; the low-level _seal_with()
    # is the migration-script path. A v0x03 envelope written without
    # a name can be opened without a name.
    env_unbound = _seal_with(b"fixture", MASTER, HEADER_V3, name=b"")
    assert open_envelope(env_unbound, MASTER, require_binding=False) == b"fixture"
    # And the public seal() (which now writes v0x04 since v1.3.4)
    # with a name still requires the matching name on read.
    env_bound = seal(b"fixture", MASTER, name=b"fixture")
    with pytest.raises(SecretEnvelopeError) as excinfo:
        open_envelope(env_bound, MASTER)
    assert "name binding required" in str(excinfo.value)


# ---------- 5. two v0x03 envelopes of the same plaintext + same name differ ----------


def test_two_envelopes_same_name_different_ciphertexts():
    """Two v0x03 envelopes sealed with identical plaintext and
    identical name produce different ciphertexts. The KDF salt
    (strict_nonce + aead_nonce) is random per seal, so even with
    name-binding the ciphertexts are indistinguishable from random.
    """
    pt = b"the same plaintext"
    e1 = _seal_with(pt, MASTER, HEADER_V3, name=b"shared")
    e2 = _seal_with(pt, MASTER, HEADER_V3, name=b"shared")
    assert e1 != e2
    # Both open with the same name.
    assert open_envelope(e1, MASTER, name=b"shared") == pt
    assert open_envelope(e2, MASTER, name=b"shared") == pt


# ---------- 6. tampered name or ciphertext fails the AEAD tag check ----------


def test_tampered_name_or_ciphertext_fails_aead():
    """Flipping a bit in the ciphertext OR in the name supplied to
    the reader must cause the tag verification to fail. The error
    message is intentionally ambiguous (same as the confused-deputy
    test) to avoid leaking which side was tampered with.
    """
    env = _seal_with(b"protected secret", MASTER, HEADER_V3, name=b"key1")
    # Tamper with the ciphertext.
    bad_ct = bytearray(env)
    ct_start = 6 + (4 + STRICT_NONCE_LEN) + NONCE_LEN  # header+ext+nonce
    bad_ct[ct_start + 1] ^= 0x10
    with pytest.raises(SecretEnvelopeError):
        open_envelope(bytes(bad_ct), MASTER, name=b"key1")
    # Tamper with the name (supply a different name to the reader).
    with pytest.raises(SecretEnvelopeError):
        open_envelope(env, MASTER, name=b"key2")


# ---------- 7. v0x01 and v0x02 envelopes still open without binding ----------


def test_v01_v02_envelopes_still_open_without_binding():
    """v0x01 (DHC1) and v0x02 (DHC2) envelopes pre-date ADR-0013.
    They do not bind the name; the reader still opens them
    correctly without a name argument.
    """
    # v0x01
    e1 = _seal_with(b"legacy v0x01", MASTER, HEADER_V1)
    assert e1[:4] == HEADER_V1
    assert open_envelope(e1, MASTER) == b"legacy v0x01"
    # v0x02
    e2 = _seal_with(b"legacy v0x02", MASTER, HEADER_V2)
    assert e2[:4] == HEADER_V2
    assert open_envelope(e2, MASTER) == b"legacy v0x02"
    # v0x01 and v0x02 also accept a name argument (it is ignored).
    assert open_envelope(e1, MASTER, name=b"ignored") == b"legacy v0x01"
    assert open_envelope(e2, MASTER, name=b"ignored") == b"legacy v0x02"


# ---------- 8. production path through SecretsService binds the name ----------


def test_v03_default_seal_path_includes_name_in_aad(tmp_path: Path):
    """End-to-end through SecretsService.put_raw / get_raw: the
    name is propagated from the JSONL record to the MAC input.
    This is the production path; it must bind the name without
    any extra wiring at the call site.
    """
    svc = SecretsService(tmp_path)
    svc.put("openai_api_key", "sk-test-1234567890")
    # The reader side is a brand-new service instance, replaying
    # the log from disk.
    svc2 = SecretsService(tmp_path)
    assert svc2.get("openai_api_key") == "sk-test-1234567890"
    # Direct corruption of the on-disk blob under a different name
    # fails. Take the openai_api_key blob, then write a fresh log
    # that stores it under anthropic_api_key. The reader raises.
    import base64, json
    log_lines = (tmp_path / "secrets.log").read_text(encoding="utf-8").splitlines()
    rec = json.loads(log_lines[0])
    # Confirm the blob starts with DHC4 (v0x04 default since v1.3.4).
    blob = base64.b64decode(rec["blob"])
    assert blob[:4] == HEADER_V4
    # Build a swapped-only log in a fresh directory; this isolates
    # the swap from the original write so the original name still
    # reads correctly in the original log.
    swap_dir = tmp_path / "swap"
    swap_dir.mkdir()
    swapped = {"op": "set", "name": "anthropic_api_key", "blob": rec["blob"]}
    (swap_dir / "secrets.log").write_text(
        json.dumps(swapped, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )
    svc_swap = SecretsService(swap_dir)
    # The swapped name fails (this is the property we just added).
    with pytest.raises(SecretEnvelopeError):
        svc_swap.get("anthropic_api_key")
