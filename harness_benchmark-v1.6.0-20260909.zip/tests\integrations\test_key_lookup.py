"""Tests for dhc.integrations.key_lookup (ADR-0007 v1.3.2 amendment).

Pins the per-model → per-provider fallback chain for API key
resolution. Tests use a tiny in-memory `dict` as the secrets
backend so the helper is exercised without touching the disk.
"""
from __future__ import annotations

import pytest

from dhc.integrations.key_lookup import (
    additional_key_name,
    default_key_name,
    lookup_api_key,
    parse_key_name,
    provider_fallback_key_name,
)


class MemorySecrets:
    def __init__(self, data: dict[str, str] | None = None) -> None:
        self._data = dict(data or {})

    def get(self, name: str) -> str | None:
        return self._data.get(name)


# ---------- name builders ----------


def test_default_key_name():
    assert default_key_name("openai", "gpt-4o-mini") == "llm_provider_openai_gpt-4o-mini"
    assert default_key_name("anthropic", "claude-3-5-sonnet-latest") == (
        "llm_provider_anthropic_claude-3-5-sonnet-latest"
    )


def test_additional_key_name_uses_triple_underscore():
    assert additional_key_name("openai", "gpt-4o-mini", 2) == "llm_provider_openai_gpt-4o-mini___2"
    assert additional_key_name("openai", "gpt-4o-mini", 3) == "llm_provider_openai_gpt-4o-mini___3"


def test_additional_key_name_rejects_n_less_than_2():
    with pytest.raises(ValueError):
        additional_key_name("openai", "gpt-4o-mini", 1)


def test_provider_fallback_key_name():
    # Caller is expected to strip the provider prefix from the model
    # id before calling (this helper takes the bare model_part).
    assert provider_fallback_key_name("openai", "gpt-4o-mini") == (
        "llm_provider_openai_gpt-4o-mini"
    )


# ---------- parse_key_name ----------


def test_parse_key_name_canonical():
    assert parse_key_name("llm_provider_openai_gpt-4o-mini") == ("openai", "gpt-4o-mini", 1)


def test_parse_key_name_additional():
    assert parse_key_name("llm_provider_openai_gpt-4o-mini___2") == ("openai", "gpt-4o-mini", 2)
    assert parse_key_name("llm_provider_anthropic_claude-3-5-sonnet-latest___7") == (
        "anthropic", "claude-3-5-sonnet-latest", 7
    )


def test_parse_key_name_unrelated():
    assert parse_key_name("model_config_s_abc") is None
    assert parse_key_name("not_a_secret") is None
    assert parse_key_name("llm_provider_openai_") is None  # missing model_part


# ---------- lookup_api_key: per-model match wins ----------


def test_lookup_per_model_match_wins_over_per_provider():
    """A v1.3.2 user who saved per-model keys (openai/gpt-4o-mini AND
    openai/gpt-4.1) gets the per-model key back, not the per-provider
    fallback."""
    secrets = MemorySecrets({
        "llm_provider_openai_gpt-4o-mini": "sk-per-model",
        # v1.3.1-style per-provider fallback stored under the first model.
        "llm_provider_openai_gpt-4.1": "sk-other",
    })
    key = lookup_api_key(
        "openai", "gpt-4o-mini", secrets.get,
        provider_first_model_id="gpt-4o-mini",
    )
    assert key == "sk-per-model"


# ---------- lookup_api_key: ___N walk ----------


def test_lookup_falls_through_to_additional_key():
    """If the canonical key is missing, the helper walks ___2, ___3,
    ... and returns the first one that resolves."""
    secrets = MemorySecrets({
        "llm_provider_openai_gpt-4o-mini___2": "sk-second",
    })
    key = lookup_api_key(
        "openai", "gpt-4o-mini", secrets.get,
        provider_first_model_id="gpt-4o-mini",
    )
    assert key == "sk-second"


def test_lookup_walks_additional_in_order():
    """The helper walks ___2 before ___3. (Both are set; we want the
    first one, not the last.)"""
    secrets = MemorySecrets({
        "llm_provider_openai_gpt-4o-mini___3": "sk-third",
        "llm_provider_openai_gpt-4o-mini___2": "sk-second",
    })
    key = lookup_api_key(
        "openai", "gpt-4o-mini", secrets.get,
        provider_first_model_id="gpt-4o-mini",
    )
    assert key == "sk-second"


# ---------- lookup_api_key: per-provider fallback ----------


def test_lookup_per_provider_fallback_when_no_per_model_key():
    """A v1.3.1 user who set one key per provider (under the first
    model) is still supported: the helper falls back to the
    per-provider key when no per-model key exists for the requested
    model."""
    secrets = MemorySecrets({
        "llm_provider_openai_gpt-4o-mini": "sk-per-provider",
    })
    # The user is asking for gpt-4.1, but only the per-provider key
    # (under gpt-4o-mini) is set.
    key = lookup_api_key(
        "openai", "gpt-4.1", secrets.get,
        provider_first_model_id="gpt-4o-mini",
    )
    assert key == "sk-per-provider"


def test_lookup_per_model_wins_over_per_provider_fallback():
    """The per-model key is preferred over the per-provider fallback,
    even when both resolve."""
    secrets = MemorySecrets({
        "llm_provider_openai_gpt-4.1": "sk-per-model-4-1",
        "llm_provider_openai_gpt-4o-mini": "sk-per-provider",
    })
    key = lookup_api_key(
        "openai", "gpt-4.1", secrets.get,
        provider_first_model_id="gpt-4o-mini",
    )
    assert key == "sk-per-model-4-1"


# ---------- lookup_api_key: missing both ----------


def test_lookup_returns_none_when_no_key_present():
    """Regression guard for the v1.3.0 behavior: when no key is
    stored at all, the helper returns None and the caller is
    expected to raise ProviderError(status=401)."""
    secrets = MemorySecrets({})
    key = lookup_api_key(
        "openai", "gpt-4o-mini", secrets.get,
        provider_first_model_id="gpt-4o-mini",
    )
    assert key is None


def test_lookup_fallback_disabled_when_first_model_is_none():
    """When `provider_first_model_id` is None, the per-provider
    fallback is skipped."""
    secrets = MemorySecrets({
        "llm_provider_openai_gpt-4o-mini": "sk-other-provider",
    })
    # The user asks for gpt-4.1 with no fallback. The key under
    # gpt-4o-mini must NOT be returned.
    key = lookup_api_key(
        "openai", "gpt-4.1", secrets.get,
        provider_first_model_id=None,
    )
    assert key is None
