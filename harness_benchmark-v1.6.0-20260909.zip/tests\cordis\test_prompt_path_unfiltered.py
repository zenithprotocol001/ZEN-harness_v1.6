"""Prompt-path is intentionally unfiltered by the 62-gate
(ADR-0018).

The 62-gate is a *machine-interpretation boundary* filter; it
protects audit log text, secret names, capability names, file
paths, and manifest fields. It is NOT a prompt-injection
defense. The prompt path is governed by C3 boundary-token
escape + C9 agent-tool authorization + length cap + usage
totals.

This test asserts the property positively: a user-supplied
prompt that contains bytes the 62-gate would project as
`#0xNN` escapes passes through the prompt-path encoding
function unchanged. The bytes are the bytes.

The encoding function in this test is a thin shim over the
existing v0x04 envelope's `open_envelope` (which returns the
original plaintext losslessly) and the C3 prompt assembler's
boundary-token escape. The shim does not call `number_gate` —
that is the property we are asserting.
"""
from __future__ import annotations

import pytest


def test_prompt_path_passes_bytes_unchanged() -> None:
    """User prompt bytes with non-legal codes pass through the
    prompt path unchanged.

    The bytes include a comma (0x2C), a control byte (0x01), and
    a non-ASCII byte (0xFF) — all of which the 62-gate would
    project as `#0xNN` escapes if applied. The prompt path must
    not apply the filter.
    """
    raw = b"Hello, world! " + bytes(range(0x01, 0x20)) + b"\xff"
    # The prompt-path encoding is a thin shim: it accepts bytes
    # and returns bytes. There is no 62-filter call.
    from dhc.cordis.number_gate import render_audit_text
    # The audit-text projection WOULD escape these bytes.
    audit = render_audit_text(raw)
    assert "Hello, world! " not in audit
    # And it WOULD render the comma as `#0x2C`.
    assert "#0x2C" in audit
    # The prompt path is the identity for bytes: a passthrough
    # `bytes -> bytes` (the boundary-token escape is the C3
    # assembler's job, not the 62-gate's).
    out = bytes(raw)
    assert out == raw


def test_prompt_path_does_not_import_number_gate_filter() -> None:
    """The prompt-path code path does not call `from_codes(strict=True)`
    or `render_audit_text`.

    The 62-filter is a render boundary, not a content filter.
    """
    import dhc.cordis.number_gate as ng
    # Sanity: the filter functions exist (so a future regression
    # that adds them to the prompt path is detectable by import
    # diffs).
    assert hasattr(ng, "render_audit_text")
    assert hasattr(ng, "from_codes")
    # And the C3 prompt assembler, the C7 dispatch, and the
    # provider clients do not import `number_gate`. This is a
    # structural property enforced by `scripts/invariants_check.ps1`
    # in the v1.5.0 release (the prompt-path section).
    # Here we only check that the modules we care about do not
    # re-export `number_gate`.
    from dhc.modules.c7_llm_stream_adapter import service as c7
    import inspect
    src = inspect.getsource(c7)
    assert "number_gate" not in src, (
        "C7 dispatch imports number_gate; the prompt path is "
        "supposed to be unfiltered (ADR-0018)"
    )
