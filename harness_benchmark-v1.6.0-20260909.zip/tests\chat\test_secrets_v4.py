"""Tests for dhc.cordis.secrets v0x04 envelope (ADR-0014).

v1.3.4 introduces the v0x04 envelope (`DHC4`) with a canonical MAC
input that length-prefixes the secret name with `u32 BE`. This
closes the field-boundary shift forgery that the v0x03 `name ‖ ct`
boundary admits: in v0x03, two adjacent variable-length fields are
concatenated raw, so an attacker can move bytes between them
without changing the MAC input. In v0x04, the `len(name):u32`
prefix disambiguates the boundary.

Wire format on disk is byte-for-byte identical to v0x03 — only
the MAC input rule at seal/open time differs. The 4-byte header
distinguishes which rule the reader applies.

v0x04 is the new default write path (since v1.3.4). v0x03 remains
read-only with its non-canonical MAC input rule for backward
compatibility with v1.3.3 envelopes.
"""
from __future__ import annotations

import base64
import json
import struct
from pathlib import Path

import pytest

from dhc.cordis.secrets import (
    HEADER_V1,
    HEADER_V2,
    HEADER_V3,
    HEADER_V4,
    NONCE_LEN,
    NAME_LEN_LEN,
    STRICT_NONCE_LEN,
    SecretEnvelopeError,
    SecretsService,
    TAG_LEN,
    _seal_with,
    open_envelope,
    seal,
)


MASTER = b"k" * 32


# ---------- 1. v0x04 + canonical MAC round-trip preserves plaintext ----------


def test_v04_aad_roundtrip_preserves_plaintext():
    """seal(name=A) → open(name=A) returns the original plaintext
    for the v0x04 envelope, including at HMAC block boundaries."""
    for n in [0, 1, 15, 16, 17, 31, 32, 33, 100, 1024, 65536]:
        pt = bytes((i * 7 + 3) & 0xFF for i in range(n))
        env = seal(pt, MASTER, name=b"alpha")
        assert env[:4] == HEADER_V4
        assert open_envelope(env, MASTER, name=b"alpha") == pt


# ---------- 2. field-boundary shift forgery fails on v0x04 ----------


def test_v04_field_boundary_shift_fails():
    """The headline test for ADR-0014. A v0x03 envelope with
    `name=b"A"` and `ct=b"BC"` has the same MAC input segment
    `b"ABC"` as a v0x03 envelope with `name=b"AB"` and
    `ct=b"C"`, so the v0x03 MAC cannot tell the two apart. The
    v0x04 envelope length-prefixes `name` with `u32 BE`, so the
    `len(name):u32` differs (`0x00000001` for `name="A"`,
    `0x00000002` for `name="AB"`) and the MAC input differs.

    This test forges a candidate (name, ct) pair from a known
    v0x04 envelope and verifies the forgery is rejected.
    """
    # Seal a v0x04 envelope with name="A" and a 3-byte plaintext.
    pt = b"BCX"
    env = seal(pt, MASTER, name=b"A")
    # The attacker wants to re-open the envelope with name="AB".
    # The MAC input the sealer used was:
    #   header ‖ ext_area ‖ nonce ‖ pack(">I", 1) ‖ b"A"
    # The MAC input the attacker would need is:
    #   header ‖ ext_area ‖ nonce ‖ pack(">I", 2) ‖ b"AB"
    # These differ. The "forged" envelope with name="AB" cannot
    # be made from the original envelope's bytes; the only way
    # to satisfy the tag check is to know the original name.
    with pytest.raises(SecretEnvelopeError):
        open_envelope(env, MASTER, name=b"AB")


# ---------- 3. v0x03 envelopes are still readable (legacy compat) ----------


def test_v03_envelope_still_readable():
    """A v0x03 envelope written by v1.3.3 is readable by the
    v1.3.4 reader. The v0x03 MAC input rule is preserved for
    read-only compatibility; new writes go to v0x04.
    """
    env = _seal_with(b"v0x03 secret", MASTER, HEADER_V3, name=b"shared")
    assert env[:4] == HEADER_V3
    assert open_envelope(env, MASTER, name=b"shared") == b"v0x03 secret"


# ---------- 4. v0x01 / v0x02 envelopes are still readable ----------


def test_v01_v02_envelopes_still_readable():
    """v0x01 (DHC1) and v0x02 (DHC2) envelopes pre-date both
    ADR-0013 (name binding) and ADR-0014 (canonical MAC input).
    The reader opens them correctly.
    """
    e1 = _seal_with(b"legacy v0x01", MASTER, HEADER_V1, name=b"ignored")
    assert e1[:4] == HEADER_V1
    assert open_envelope(e1, MASTER, name=b"ignored") == b"legacy v0x01"
    e2 = _seal_with(b"legacy v0x02", MASTER, HEADER_V2, name=b"ignored")
    assert e2[:4] == HEADER_V2
    assert open_envelope(e2, MASTER, name=b"ignored") == b"legacy v0x02"


# ---------- 5. v0x04 is the default seal path through SecretsService ----------


def test_v04_default_seal_path(tmp_path: Path):
    """End-to-end through SecretsService.put_raw / get_raw: the
    production path writes v0x04 envelopes. The on-disk blob
    starts with `DHC4`.
    """
    svc = SecretsService(tmp_path)
    svc.put("openai_api_key", "sk-test-1234567890")
    svc2 = SecretsService(tmp_path)
    assert svc2.get("openai_api_key") == "sk-test-1234567890"
    # Inspect the on-disk blob.
    import base64, json
    log_text = (tmp_path / "secrets.log").read_text(encoding="utf-8")
    rec = json.loads(log_text.strip().splitlines()[0])
    blob = base64.b64decode(rec["blob"])
    assert blob[:4] == HEADER_V4


# ---------- 6. migration script refuses anonymous v0x03 envelopes ----------


def test_migrate_refuses_anonymous_v03_envelope(tmp_path: Path, monkeypatch):
    """A v0x03 envelope sealed with `name=b""` (anonymous) is
    a downgrade vector: a migration script that reads with
    `require_binding=False` would accept it, and the attacker
    could plant it pre-migration. The migration script refuses
    to migrate such envelopes.
    """
    # Plant an anonymous v0x03 envelope in a fresh log.
    swap_dir = tmp_path / "anon"
    swap_dir.mkdir()
    blob = _seal_with(b"anonymous value", MASTER, HEADER_V3, name=b"")
    rec = {"op": "set", "name": "", "blob": base64.b64encode(blob).decode("ascii")}
    (swap_dir / "secrets.log").write_text(
        json.dumps(rec, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )
    # Copy the master key to swap_dir/secrets.key.
    (swap_dir / "secrets.key").write_bytes(MASTER)
    # Run the migration script.
    from scripts import migrate_v03_to_v04
    with pytest.raises(SecretEnvelopeError) as excinfo:
        migrate_v03_to_v04.migrate(swap_dir)
    assert "refusing to migrate anonymous" in str(excinfo.value)


# ---------- 7. name length prefix is big-endian u32 ----------


def test_v04_name_length_prefix_is_big_endian_u32():
    """The MAC input's `len(name):u32` prefix is big-endian
    (4 bytes). Sanity check: for a 5-byte name, the prefix is
    `b"\\x00\\x00\\x00\\x05"`. We verify the prefix bytes
    appear in the MAC input by inspecting the structure of the
    envelope (we cannot inspect the MAC input directly because
    it is fed to HMAC, but we can verify the seal/open symmetry
    holds across a name length that exercises the u32 boundary).
    """
    # 5-byte name: 0x00 0x00 0x00 0x05
    for name in [b"a", b"ab", b"abc", b"abcd", b"abcde", b"x" * 256, b"y" * 65536]:
        env = seal(b"payload", MASTER, name=name)
        assert env[:4] == HEADER_V4
        assert open_envelope(env, MASTER, name=name) == b"payload"
    # Endianness check: the prefix is `>I` (struct.big-endian u32).
    # We can verify by building a v0x04 envelope and confirming
    # that the seal/open pair is symmetric for a name that is
    # sensitive to the prefix's byte order.
    name = b"x" * 256
    prefix = struct.pack(">I", len(name))  # big-endian u32
    assert prefix == b"\x00\x00\x01\x00"  # 256 in big-endian


# ---------- 8. two v0x04 envelopes of same plaintext + name differ ----------


def test_two_v04_envelopes_same_name_different_ciphertexts():
    """Two v0x04 envelopes sealed with identical plaintext and
    identical name produce different ciphertexts. The KDF salt
    (`strict_nonce ‖ aead_nonce`) and AEAD nonce are random per
    seal, so even with the canonical MAC input the ciphertexts
    are indistinguishable from random.
    """
    pt = b"the same plaintext"
    e1 = seal(pt, MASTER, name=b"shared")
    e2 = seal(pt, MASTER, name=b"shared")
    assert e1 != e2
    # Both open with the same name.
    assert open_envelope(e1, MASTER, name=b"shared") == pt
    assert open_envelope(e2, MASTER, name=b"shared") == pt
    # Confused-deputy still fails on v0x04.
    with pytest.raises(SecretEnvelopeError):
        open_envelope(e1, MASTER, name=b"other")


# ---------- Sanity: NAME_LEN_LEN is 4 ----------


def test_name_len_len_is_4():
    """The width of the name length prefix is 4 bytes (u32)."""
    assert NAME_LEN_LEN == 4
    # And `struct.pack(">I", ...)` produces 4 bytes.
    assert len(struct.pack(">I", 0)) == 4
    assert len(struct.pack(">I", 0xFFFFFFFF)) == 4
