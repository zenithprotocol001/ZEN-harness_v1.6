"""v1.5.1.4 (audit hotfix #4) — per-provider real connection probe.

The v1.5.1 `GET /api/llm/health` only confirmed the harness was
started with `--llm-base-url`; it did NOT verify the user's
OpenRouter key actually works. The Settings modal rendered a
"Configured" pill with no way to actually confirm the key was
valid. v1.5.1.4 adds a per-provider probe at
`GET /api/llm/health/{provider}` that uses OpenRouter's
canonical `GET /api/v1/auth/key` endpoint — the documented
"is my key valid" probe.

These tests mock `httpx.AsyncClient.get` so they do not
require a real OpenRouter account. They cover:

- 200 + valid key: returns `{ok, label, limit, is_free_tier}`.
- 401: returns `{ok: false, error: "invalid_key"}` and does NOT
  log the key.
- No key configured: returns `{ok: false, error: "no_key"}`.
- Network failure: returns `{ok: false, error: "network"}` and
  does NOT log the key.
- Non-OpenRouter provider: returns
  `{ok: false, error: "not_supported"}`.
"""
from __future__ import annotations

import os
import socket
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator
from unittest.mock import AsyncMock, patch

import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

from dhc.cordis.context import Context
from dhc.modules.c1_gui_web_core.service import GuiWebCore


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@asynccontextmanager
async def _running_c1(tmp_path: Path) -> AsyncIterator[tuple[TestClient, str]]:
    """Bring up a GuiWebCore with isolated sessions and secrets dirs."""
    sessions_dir = tmp_path
    secrets_dir = tmp_path / "secrets"
    secrets_dir.mkdir()
    gwc = GuiWebCore(
        host="127.0.0.1",
        port=0,
        require_token=True,
        sessions_dir=sessions_dir,
        secrets_dir=secrets_dir,
    )
    gwc.app["ctx"] = Context()
    server = TestServer(gwc.app)
    client = TestClient(server)
    await client.start_server()
    try:
        yield client, gwc.token
    finally:
        await client.close()


def _mock_httpx_get(status_code: int, json_body: dict[str, Any] | None = None) -> AsyncMock:
    """Build an AsyncMock that mimics `httpx.AsyncClient.get`.

    `httpx.Response.json` is a sync method that parses the
    response body — it returns a dict, not a coroutine. The
    production code calls it without `await`.
    """
    mock_resp = AsyncMock()
    mock_resp.status_code = status_code
    # `json` is a sync method (returns a dict, not a coroutine).
    mock_resp.json = lambda: json_body or {}
    mock_get = AsyncMock()
    mock_get.return_value = mock_resp
    return mock_get


@pytest.mark.asyncio
async def test_llm_health_openrouter_200_returns_label_and_limit(
    tmp_path: Path,
) -> None:
    """A 200 from OpenRouter /auth/key means the key is valid.
    The response is mapped to `{ok: true, label, limit, is_free_tier}`."""
    async with _running_c1(tmp_path) as (client, token):
        # Seed an OpenRouter key under the canonical per-provider
        # fallback name `llm_provider_openrouter_auto` (per
        # ADR-0007 v1.3.2).
        gwc = client.app["web_core"]
        gwc.secrets_service.put_raw("llm_provider_openrouter_auto", b"sk-or-v1-test-valid")

        mock_get = _mock_httpx_get(
            200,
            {
                "data": {
                    "label": "Test OpenRouter Key",
                    "usage": 0.001,
                    "limit": 100.0,
                    "is_free_tier": False,
                }
            },
        )
        with patch("httpx.AsyncClient.get", mock_get):
            r = await client.get(
                "/api/llm/health/openrouter",
                headers={"Authorization": f"Bearer {token}"},
            )
        assert r.status == 200
        body = await r.json()
        assert body["ok"] is True
        assert body["provider"] == "openrouter"
        assert body["label"] == "Test OpenRouter Key"
        assert body["limit"] == 100.0
        assert body["is_free_tier"] is False
        # The Authorization header was sent with the user's key
        # (not echoed back in the response).
        sent_headers = mock_get.call_args.kwargs["headers"]
        assert sent_headers["Authorization"] == "Bearer sk-or-v1-test-valid"


@pytest.mark.asyncio
async def test_llm_health_openrouter_401_returns_invalid_key(
    tmp_path: Path,
) -> None:
    """A 401 from OpenRouter /auth/key means the key is invalid
    (or revoked, or expired). The response maps to
    `{ok: false, error: "invalid_key"}`. The key value is
    never echoed in the response body or logged."""
    async with _running_c1(tmp_path) as (client, token):
        gwc = client.app["web_core"]
        gwc.secrets_service.put_raw("llm_provider_openrouter_auto", b"sk-or-v1-bogus")

        mock_get = _mock_httpx_get(401, {"error": "Unauthorized"})
        with patch("httpx.AsyncClient.get", mock_get):
            r = await client.get(
                "/api/llm/health/openrouter",
                headers={"Authorization": f"Bearer {token}"},
            )
        assert r.status == 200  # the route itself succeeds; the
        # body is the structured `{ok: false, error: ...}`
        # (we don't surface 401 to the client because the
        # user-friendly error is in the body)
        body = await r.json()
        assert body["ok"] is False
        assert body["provider"] == "openrouter"
        assert body["error"] == "invalid_key"
        # The key is NOT in the response body.
        assert "sk-or-v1-bogus" not in str(body)
        # The key IS in the outgoing Authorization header
        # (the route hands it to httpx; httpx sends it; the
        # response is what we control for the leak).
        sent_headers = mock_get.call_args.kwargs["headers"]
        assert sent_headers["Authorization"] == "Bearer sk-or-v1-bogus"


@pytest.mark.asyncio
async def test_llm_health_openrouter_no_key_returns_no_key(
    tmp_path: Path,
) -> None:
    """If no key is configured for the OpenRouter provider,
    the probe returns `{ok: false, error: "no_key"}` without
    making any upstream call."""
    async with _running_c1(tmp_path) as (client, token):
        mock_get = _mock_httpx_get(200)  # would be a problem if called
        with patch("httpx.AsyncClient.get", mock_get) as m:
            r = await client.get(
                "/api/llm/health/openrouter",
                headers={"Authorization": f"Bearer {token}"},
            )
        # httpx.get must NOT have been called — short-circuit
        # when no key is configured.
        m.assert_not_called()
        assert r.status == 200
        body = await r.json()
        assert body["ok"] is False
        assert body["provider"] == "openrouter"
        assert body["error"] == "no_key"


@pytest.mark.asyncio
async def test_llm_health_openrouter_network_failure_returns_network(
    tmp_path: Path,
) -> None:
    """A network/timeout/DNS failure during the probe returns
    `{ok: false, error: "network"}` without surfacing the
    exception to the client (no key leak)."""
    async with _running_c1(tmp_path) as (client, token):
        gwc = client.app["web_core"]
        gwc.secrets_service.put_raw("llm_provider_openrouter_auto", b"sk-or-v1-network-fail")

        # The httpx call raises a generic exception.
        mock_get = AsyncMock(side_effect=ConnectionError("simulated DNS failure"))
        with patch("httpx.AsyncClient.get", mock_get):
            r = await client.get(
                "/api/llm/health/openrouter",
                headers={"Authorization": f"Bearer {token}"},
            )
        assert r.status == 200
        body = await r.json()
        assert body["ok"] is False
        assert body["provider"] == "openrouter"
        assert body["error"] == "network"
        # The key is NOT in the response body.
        assert "sk-or-v1-network-fail" not in str(body)


@pytest.mark.asyncio
async def test_llm_health_openai_returns_not_supported(
    tmp_path: Path,
) -> None:
    """OpenAI does not expose a public /auth/key probe. The
    route returns `{ok: false, error: "not_supported"}` and
    the frontend falls back to the existing 'configured' pill."""
    async with _running_c1(tmp_path) as (client, token):
        r = await client.get(
            "/api/llm/health/openai",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert r.status == 200
        body = await r.json()
        assert body["ok"] is False
        assert body["provider"] == "openai"
        assert body["error"] == "not_supported"
