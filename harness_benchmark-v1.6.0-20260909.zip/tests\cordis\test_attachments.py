"""Tests for dhc.cordis.attachments (v1.5.0, ADR-0020).

12 tests covering:

1. MIME allowlist is the 10 values in the ADR-0020 table.
2. Inline MIME set is exactly text/plain, text/markdown, image/svg+xml.
3. Out-of-line MIME set is the 7 binary types.
4. Ref format invariants: `attachment:{session_id}:{uuid}`.
5. parse_attachment_ref rejects malformed refs.
6. Round-trip on out-of-line payload (bytes are exact).
7. SHA-256 metadata matches the original bytes.
8. File size cap (reject > 10 MB).
9. MIME rejection (text/plain is not out-of-line).
10. Delete cleans the .bin and .json files; not-found is 404.
11. Per-message size cap (reject > 25 MB).
12. Inline text/SVG content does not require the attachment
    service (it lives in `Message.attachments` directly).
"""
from __future__ import annotations

import json
import pytest
from pathlib import Path

from dhc.cordis.attachments import (
    AttachmentService,
    AttachmentMIMEError,
    AttachmentNotFoundError,
    AttachmentSizeError,
    MAX_ATTACHMENT_BYTES,
    MAX_MESSAGE_ATTACHMENT_BYTES,
    MIME_ALLOWLIST,
    MIME_INLINE,
    MIME_OUT_OF_LINE,
    attachment_ref,
    is_mime_allowed,
    is_mime_inline,
    parse_attachment_ref,
)


# ---------- 1. MIME allowlist shape ----------


def test_mime_allowlist_is_10_values() -> None:
    """The full allowlist is exactly 10 MIME types (ADR-0020)."""
    assert len(MIME_ALLOWLIST) == 10
    # All 10 are present and no extras.
    expected = {
        "text/plain",
        "text/markdown",
        "image/svg+xml",
        "image/png",
        "image/jpeg",
        "image/gif",
        "image/webp",
        "audio/mpeg",
        "audio/wav",
        "application/pdf",
    }
    assert MIME_ALLOWLIST == expected


# ---------- 2. Inline MIME set ----------


def test_inline_mime_is_text_and_svg() -> None:
    """Inline MIME is text/plain, text/markdown, image/svg+xml."""
    assert MIME_INLINE == frozenset({
        "text/plain",
        "text/markdown",
        "image/svg+xml",
    })
    # is_mime_inline agrees with the set.
    for m in MIME_INLINE:
        assert is_mime_inline(m)
    for m in MIME_OUT_OF_LINE:
        assert not is_mime_inline(m)


# ---------- 3. Out-of-line MIME set ----------


def test_out_of_line_mime_is_binary() -> None:
    """Out-of-line MIME is the 7 binary types."""
    assert len(MIME_OUT_OF_LINE) == 7
    assert MIME_OUT_OF_LINE == frozenset({
        "image/png",
        "image/jpeg",
        "image/gif",
        "image/webp",
        "audio/mpeg",
        "audio/wav",
        "application/pdf",
    })


# ---------- 4. Ref format invariants ----------


def test_ref_format_invariants() -> None:
    """The ref format is `attachment:{session_id}:{uuid}`."""
    ref = attachment_ref("s_abc", "0" * 32)
    assert ref == "attachment:s_abc:" + "0" * 32
    parsed = parse_attachment_ref(ref)
    assert parsed == ("s_abc", "0" * 32)
    # is_mime_allowed is a separate concern; sanity check.
    assert is_mime_allowed("text/plain")
    assert not is_mime_allowed("text/html")
    assert not is_mime_allowed("application/zip")


# ---------- 5. Malformed refs are rejected ----------


@pytest.mark.parametrize(
    "bad_ref",
    [
        "",
        "attachment:",
        "attachment:abc",  # missing uuid
        "attachment:abc:xyz",  # uuid wrong format
        "attachment:abc:" + "z" * 32,  # uuid wrong charset
        "secret:abc:" + "0" * 32,  # wrong prefix
        "attachment:abc:" + "0" * 31,  # uuid too short
        "attachment:abc:" + "0" * 33,  # uuid too long
    ],
)
def test_parse_attachment_ref_rejects_malformed(bad_ref: str) -> None:
    assert parse_attachment_ref(bad_ref) is None


# ---------- 6. Round-trip on out-of-line payload ----------


def test_out_of_line_round_trip(tmp_path: Path) -> None:
    """Out-of-line: put(bytes, mime) → get(ref) returns exact bytes."""
    from dhc.cordis.secrets import SecretsService
    secd = tmp_path / "secrets"
    secd.mkdir()
    secrets = SecretsService(secd)
    att_dir = tmp_path / "attachments"
    svc = AttachmentService(att_dir, secrets)
    payload = b"\x89PNG\r\n\x1a\n fake png bytes" * 50
    meta = svc.put("s_test", payload, "image/png")
    out, m2 = svc.get(meta["ref"])
    assert out == payload


# ---------- 7. SHA-256 metadata matches ----------


def test_sha256_metadata(tmp_path: Path) -> None:
    """The metadata's sha256 matches sha256(payload)."""
    import hashlib
    from dhc.cordis.secrets import SecretsService
    secd = tmp_path / "secrets"
    secd.mkdir()
    secrets = SecretsService(secd)
    svc = AttachmentService(tmp_path / "attachments", secrets)
    payload = b"hello"
    meta = svc.put("s_x", payload, "image/png")
    assert meta["sha256"] == hashlib.sha256(payload).hexdigest()


# ---------- 8. Per-file size cap ----------


def test_per_file_size_cap(tmp_path: Path) -> None:
    """Reject payloads > MAX_ATTACHMENT_BYTES."""
    from dhc.cordis.secrets import SecretsService
    secd = tmp_path / "secrets"
    secd.mkdir()
    secrets = SecretsService(secd)
    svc = AttachmentService(tmp_path / "attachments", secrets)
    # Construct a payload > 10 MB.
    big = b"x" * (MAX_ATTACHMENT_BYTES + 1)
    with pytest.raises(AttachmentSizeError):
        svc.put("s_big", big, "image/png")


# ---------- 9. MIME rejection ----------


def test_mime_rejection_text_is_not_out_of_line(tmp_path: Path) -> None:
    """`text/plain` is not in MIME_OUT_OF_LINE; rejected by `put`."""
    from dhc.cordis.secrets import SecretsService
    secd = tmp_path / "secrets"
    secd.mkdir()
    secrets = SecretsService(secd)
    svc = AttachmentService(tmp_path / "attachments", secrets)
    with pytest.raises(AttachmentMIMEError):
        svc.put("s_x", b"hello", "text/plain")
    with pytest.raises(AttachmentMIMEError):
        svc.put("s_x", b"hello", "text/html")  # not even on the allowlist
    with pytest.raises(AttachmentMIMEError):
        svc.put("s_x", b"hello", "application/zip")


# ---------- 10. Delete cleans files; not-found is 404 ----------


def test_delete_and_not_found(tmp_path: Path) -> None:
    """`delete` removes the .bin and .json files."""
    from dhc.cordis.secrets import SecretsService
    secd = tmp_path / "secrets"
    secd.mkdir()
    secrets = SecretsService(secd)
    svc = AttachmentService(tmp_path / "attachments", secrets)
    meta = svc.put("s_x", b"x", "image/png")
    # Files exist.
    sid_dir = tmp_path / "attachments" / "s_x"
    bin_path = sid_dir / (meta["ref"].rsplit(":", 1)[1] + ".bin")
    json_path = sid_dir / (meta["ref"].rsplit(":", 1)[1] + ".json")
    assert bin_path.exists()
    assert json_path.exists()
    # Delete cleans both.
    svc.delete(meta["ref"])
    assert not bin_path.exists()
    assert not json_path.exists()
    # Deleting again is 404.
    with pytest.raises(AttachmentNotFoundError):
        svc.delete(meta["ref"])


# ---------- 11. Per-message size cap ----------


def test_per_message_size_cap() -> None:
    """Reject message attachment totals > MAX_MESSAGE_ATTACHMENT_BYTES."""
    # Build a 26 MB aggregate: one 26 MB out-of-line ref.
    big = {"size": MAX_MESSAGE_ATTACHMENT_BYTES + 1}
    with pytest.raises(AttachmentSizeError):
        AttachmentService.message_attachment_size(
            inline=None, out_of_line=[big]
        )
    # 24 MB is fine.
    ok = {"size": 24 * 1024 * 1024}
    assert AttachmentService.message_attachment_size(
        inline=None, out_of_line=[ok]
    ) == 24 * 1024 * 1024


# ---------- 12. Inline text/SVG does not need the attachment service ----------


def test_inline_text_does_not_use_attachment_service(tmp_path: Path) -> None:
    """`text/plain` goes inline in the message, not through `put`.

    The v1.5.0 design (ADR-0020) routes text/SVG content through
    `Message.attachments: list[InlineAttachment]`, not the binary
    attachment service. This test asserts the routing: a `put`
    call with `text/plain` raises, while a `Message.attachments`
    inline entry with `text/plain` is the path the API consumer
    takes. We don't construct the message here (the Session model
    is the test boundary for inline attachments); we just assert
    that the service refuses text-like MIME.
    """
    from dhc.cordis.secrets import SecretsService
    secd = tmp_path / "secrets"
    secd.mkdir()
    secrets = SecretsService(secd)
    svc = AttachmentService(tmp_path / "attachments", secrets)
    for mime in MIME_INLINE:
        with pytest.raises(AttachmentMIMEError):
            svc.put("s_x", b"x", mime)
