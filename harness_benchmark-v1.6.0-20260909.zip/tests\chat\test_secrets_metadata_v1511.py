"""v1.5.1.1 (ADR-0108) — API key management contract.

Verifies the GitHub-shaped contract:
- `GET /api/secrets` returns metadata only (no values, no `sk-` shaped
  strings in the response).
- `PUT /api/secrets/{name}` upserts with body `{value}`.
- `DELETE /api/secrets/{name}` removes a stored secret.
- The secrets log file is enforced to mode 0600; a permissive mode
  causes PUT/DELETE to return 403.

v1.5.1.2 (audit hotfix): the hint shape changed from
`first_3 + … + last_4` to `… + last_4` only. The 3-char
prefix leaked the provider family (every major provider
starts with `sk-`); the modal subtitle "Encrypted at rest,
never sent to the browser in any response" was misleading
under the prefix-leak. The new shape is just the last 4
chars prefixed with an ellipsis.

- The `names` field is preserved on GET for backwards compat.
"""
from __future__ import annotations

import os
import socket
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator

import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

from dhc.cordis.context import Context
from dhc.cordis.secrets import SecretsService, _hint_for
from dhc.modules.c1_gui_web_core.service import GuiWebCore


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@asynccontextmanager
async def _running_c1(tmp_path: Path) -> AsyncIterator[tuple[TestClient, str]]:
    """Bring up a GuiWebCore with isolated sessions and secrets dirs."""
    sessions_dir = tmp_path
    secrets_dir = tmp_path / "secrets"
    secrets_dir.mkdir()
    gwc = GuiWebCore(
        host="127.0.0.1",
        port=0,
        require_token=True,
        sessions_dir=sessions_dir,
        secrets_dir=secrets_dir,
    )
    gwc.app["ctx"] = Context()
    server = TestServer(gwc.app)
    client = TestClient(server)
    await client.start_server()
    try:
        yield client, gwc.token
    finally:
        await client.close()


# ---------- hint helper ----------


def test_hint_for_short_value_returns_empty():
    """Values shorter than 4 chars do not get a hint (the hint
    would be the whole value). v1.5.1.2: the threshold dropped
    from 7 to 4 because the hint shape changed from
    `first_3+…+last_4` (7 chars) to `…+last_4` (5 chars)."""
    assert _hint_for("") == ""
    assert _hint_for("a") == ""
    assert _hint_for("abc") == ""


def test_hint_for_long_value_returns_last_4():
    """v1.5.1.2: the hint is `…+last_4` only. The previous
    `first_3+…+last_4` shape leaked the provider family (every
    major provider starts with `sk-`); the modal's subtitle
    "never sent to the browser in any response" was misleading
    under the prefix-leak. The new shape is just the last 4
    characters prefixed with an ellipsis.
    """
    assert _hint_for("sk-1234567890") == "…7890"
    assert _hint_for("sk-ant-api03-aaaaaaaaaaaaaa") == "…aaaa"


def test_hint_redacts_provider_prefix():
    """v1.5.1.2 (audit hotfix): the hint must not contain the
    3-char provider prefix. This is the bug fix for the audit
    finding that `sk-` is a uniform prefix across OpenAI /
    Anthropic / OpenRouter and was being surfaced to the
    browser via the metadata endpoint.

    The hint is `…+last_4` (5 visible chars including the
    ellipsis). The full key value is never returned.
    """
    for key in [
        "sk-openai-1234567890ABCDEF",
        "sk-ant-api03-1234567890ABCDEF",
        "sk-or-v1-1234567890ABCDEF",
        "gsk_ANTIGRAVITY-1234567890ABCDEF",  # non-sk- prefix
        "x" * 4 + "1234",  # 8-char junk
    ]:
        hint = _hint_for(key)
        # The provider prefix must not appear in the hint.
        assert not hint.startswith("sk-"), f"hint {hint!r} leaks sk- prefix for {key!r}"
        assert not hint.startswith("sk"), f"hint {hint!r} leaks sk prefix for {key!r}"
        # The hint is `…+last_4`.
        assert hint.startswith("…"), f"hint {hint!r} should start with ellipsis"
        assert len(hint) == 5, f"hint {hint!r} should be 5 visible chars"


# ---------- GET /api/secrets metadata shape ----------


@pytest.mark.asyncio
async def test_get_secrets_returns_metadata_shape(tmp_path: Path):
    async with _running_c1(tmp_path) as (client, _token):
        # Empty list returns the new shape with empty arrays.
        r = await client.get("/api/secrets")
        assert r.status == 200
        body = await r.json()
        assert body["secrets"] == []
        assert body["names"] == []


@pytest.mark.asyncio
async def test_get_secrets_metadata_never_returns_value(tmp_path: Path):
    """The metadata endpoint must never echo the value, even
    partially. We PUT a known value then assert the GET response
    contains neither the full value nor any `sk-`-shaped substring
    that would let a reader reconstruct the secret.
    """
    async with _running_c1(tmp_path) as (client, _token):
        secret_value = "sk-supersecretvalue-1234567890"
        r = await client.put(
            "/api/secrets/openai_main",
            json={"value": secret_value},
        )
        assert r.status == 204
        r = await client.get("/api/secrets")
        body = await r.json()
        # The full value must never appear in the response.
        assert secret_value not in str(body)
        # v1.5.1.2: the hint is `…+last_4` (5 visible chars
        # including the ellipsis). The 3-char prefix is no
        # longer leaked.
        assert len(body["secrets"]) == 1
        entry = body["secrets"][0]
        assert entry["name"] == "openai_main"
        assert entry["configured"] is True
        assert "hint" in entry
        # The hint is just the last 4 chars prefixed with an
        # ellipsis. No provider-family prefix is exposed.
        assert entry["hint"] == "…7890"
        # The provider prefix must NOT appear in the hint.
        assert "sk-" not in entry["hint"]
        # Backwards compat: `names` is preserved.
        assert body["names"] == ["openai_main"]


# ---------- PUT round-trip with metadata hint ----------


@pytest.mark.asyncio
async def test_put_then_get_metadata_hint(tmp_path: Path):
    async with _running_c1(tmp_path) as (client, _token):
        r = await client.put(
            "/api/secrets/anthropic_main",
            json={"value": "sk-ant-api03-1234567890abcdef"},
        )
        assert r.status == 204
        r = await client.get("/api/secrets")
        body = await r.json()
        assert len(body["secrets"]) == 1
        assert body["secrets"][0]["hint"] == "…cdef"


# ---------- DELETE round-trip ----------


@pytest.mark.asyncio
async def test_delete_then_get_no_longer_reports_stored(tmp_path: Path):
    async with _running_c1(tmp_path) as (client, _token):
        r = await client.put(
            "/api/secrets/openrouter_main",
            json={"value": "sk-or-v1-1234567890abcdef"},
        )
        assert r.status == 204
        r = await client.get("/api/secrets")
        body = await r.json()
        assert len(body["secrets"]) == 1
        r = await client.delete("/api/secrets/openrouter_main")
        assert r.status == 204
        r = await client.get("/api/secrets")
        body = await r.json()
        assert body["secrets"] == []


# ---------- 0600 fail-loud ----------


@pytest.mark.asyncio
async def test_put_rejected_with_permissive_mode_403(tmp_path: Path):
    """If the secrets log is created with mode 0o644 (world-readable),
    PUT must be rejected with 403. This is the v1.5.1.1 fail-loud
    guarantee: the gh-cli lesson — error, never fall back.
    """
    sessions_dir = tmp_path
    secrets_dir = tmp_path / "secrets"
    secrets_dir.mkdir()
    # Pre-create the secrets log with permissive mode and one entry.
    ss = SecretsService(secrets_dir)
    ss.put("openai_main", "sk-1234567890")
    log_path = secrets_dir / "secrets.log"
    os.chmod(log_path, 0o644)
    gwc = GuiWebCore(
        host="127.0.0.1",
        port=0,
        require_token=True,
        sessions_dir=sessions_dir,
        secrets_dir=secrets_dir,
    )
    gwc.app["ctx"] = Context()
    # Run the check explicitly so the in-process service is marked
    # insecure (the constructor only logs the warning).
    try:
        gwc.secrets_service.check_permissions()
    except PermissionError:
        pass
    server = TestServer(gwc.app)
    client = TestClient(server)
    await client.start_server()
    try:
        r = await client.put(
            "/api/secrets/openai_main",
            json={"value": "sk-newvalue"},
        )
        assert r.status == 403
        body = await r.json()
        assert "insecure" in body["error"].lower() or "chmod" in body["error"].lower()
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_delete_rejected_with_permissive_mode_403(tmp_path: Path):
    """Same as above but for DELETE — both write verbs must be
    blocked when the file mode is permissive."""
    sessions_dir = tmp_path
    secrets_dir = tmp_path / "secrets"
    secrets_dir.mkdir()
    ss = SecretsService(secrets_dir)
    ss.put("openai_main", "sk-1234567890")
    log_path = secrets_dir / "secrets.log"
    os.chmod(log_path, 0o644)
    gwc = GuiWebCore(
        host="127.0.0.1",
        port=0,
        require_token=True,
        sessions_dir=sessions_dir,
        secrets_dir=secrets_dir,
    )
    gwc.app["ctx"] = Context()
    try:
        gwc.secrets_service.check_permissions()
    except PermissionError:
        pass
    server = TestServer(gwc.app)
    client = TestClient(server)
    await client.start_server()
    try:
        r = await client.delete("/api/secrets/openai_main")
        assert r.status == 403
    finally:
        await client.close()


def test_check_permissions_passes_on_missing_file(tmp_path: Path):
    """A fresh secrets dir has no log file. The check must not
    raise — it's a no-op when the file doesn't exist yet."""
    secrets_dir = tmp_path / "secrets"
    secrets_dir.mkdir()
    ss = SecretsService(secrets_dir)
    # Should not raise.
    ss.check_permissions()
    assert not ss.is_insecure_permissions


def test_check_permissions_raises_on_permissive_mode(tmp_path: Path):
    """The check raises PermissionError on a permissive log file
    and marks the service as insecure."""
    secrets_dir = tmp_path / "secrets"
    secrets_dir.mkdir()
    ss = SecretsService(secrets_dir)
    ss.put("x", "y")
    log_path = secrets_dir / "secrets.log"
    os.chmod(log_path, 0o644)
    with pytest.raises(PermissionError):
        ss.check_permissions()
    assert ss.is_insecure_permissions
