"""Tests for v1.3.2 Session.usage_totals accumulation.

The accumulation logic lives in two places: the C1 WS chat handler
and the C1 HTTP message endpoint. Both consume `StreamChunk.usage`
from the LLM provider and add it to `Session.usage_totals` after
each turn.

The handler-level tests live in `tests/chat/test_chat_ws.py` and
`tests/chat/test_c1_routes.py`. This file pins the lower-level
contract: `Session` carries the field, `SessionManager.update`
persists it, and a freshly-constructed session has the right
defaults. We also pin the accumulation math directly against the
`Session` model so the contract is testable without spinning up
the full aiohttp stack.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from dhc.services.session_manager import Session, SessionManager


# ---------- Session model: defaults ----------


def test_session_has_usage_totals_default():
    """A freshly constructed Session has the v1.3.2 `usage_totals`
    field with all five keys set to zero."""
    s = Session(
        id="s_abc",
        title="t",
        created_at=0,
        updated_at=0,
        messages=[],
    )
    assert s.usage_totals == {
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "total_tokens": 0,
        "last_turn_prompt": 0,
        "last_turn_completion": 0,
    }


def test_session_to_dict_includes_usage_totals():
    """`to_dict()` carries the `usage_totals` field so the field
    round-trips through the on-disk JSON."""
    s = Session(
        id="s_abc",
        title="t",
        created_at=0,
        updated_at=0,
        messages=[],
    )
    d = s.to_dict()
    assert "usage_totals" in d
    assert d["usage_totals"]["prompt_tokens"] == 0


def test_session_from_dict_backfills_zeros():
    """A v1.2.x / v1.3.0 / v1.3.1 session file (no
    `usage_totals` key) loads with zero defaults. Backward
    compatibility requirement."""
    d = {
        "id": "s_legacy",
        "title": "t",
        "created_at": 0,
        "updated_at": 0,
        "messages": [],
    }
    s = Session.from_dict(d)
    assert s.usage_totals["prompt_tokens"] == 0
    assert s.usage_totals["total_tokens"] == 0
    assert s.usage_totals["last_turn_prompt"] == 0


def test_session_from_dict_with_partial_usage_totals():
    """A v1.3.2 session that was written with a partial
    `usage_totals` (e.g. only `prompt_tokens` was set) loads with
    the missing fields backfilled with zeros, not `None` or
    missing."""
    d = {
        "id": "s_partial",
        "title": "t",
        "created_at": 0,
        "updated_at": 0,
        "messages": [],
        "usage_totals": {"prompt_tokens": 12, "completion_tokens": 88},
    }
    s = Session.from_dict(d)
    assert s.usage_totals["prompt_tokens"] == 12
    assert s.usage_totals["completion_tokens"] == 88
    assert s.usage_totals["total_tokens"] == 0
    assert s.usage_totals["last_turn_prompt"] == 0
    assert s.usage_totals["last_turn_completion"] == 0


# ---------- SessionManager.update: usage_totals persists ----------


def test_session_manager_update_persists_usage_totals(tmp_path: Path):
    """Calling `update(session_id, usage_totals=...)` writes the
    new totals to disk and they survive a re-read."""
    sm = SessionManager(tmp_path)
    s = sm.create()
    sid = s.id
    sm.update(sid, usage_totals={
        "prompt_tokens": 10,
        "completion_tokens": 20,
        "total_tokens": 30,
        "last_turn_prompt": 10,
        "last_turn_completion": 20,
    })
    # New instance reads the same log.
    sm2 = SessionManager(tmp_path)
    s2 = sm2.get(sid)
    assert s2 is not None
    assert s2.usage_totals["prompt_tokens"] == 10
    assert s2.usage_totals["completion_tokens"] == 20
    assert s2.usage_totals["total_tokens"] == 30


def test_session_manager_update_usage_totals_is_additive(tmp_path: Path):
    """Two consecutive updates with the same field produce the
    second value (overwrite), not the sum. The accumulation is
    done by the handler, not the manager."""
    sm = SessionManager(tmp_path)
    s = sm.create()
    sid = s.id
    sm.update(sid, usage_totals={"prompt_tokens": 5, "completion_tokens": 7, "total_tokens": 12, "last_turn_prompt": 5, "last_turn_completion": 7})
    sm.update(sid, usage_totals={"prompt_tokens": 8, "completion_tokens": 11, "total_tokens": 19, "last_turn_prompt": 8, "last_turn_completion": 11})
    s2 = sm.get(sid)
    assert s2.usage_totals["prompt_tokens"] == 8
    assert s2.usage_totals["completion_tokens"] == 11


# ---------- Accumulation math (handler-level contract) ----------


def _accumulate(prior: dict, prompt: int, completion: int) -> dict:
    """Mirror of the C1 handler's accumulation math. If this
    formula changes, both the WS and HTTP paths must change in
    lockstep; the test pins the contract."""
    return {
        "prompt_tokens": prior["prompt_tokens"] + prompt,
        "completion_tokens": prior["completion_tokens"] + completion,
        "total_tokens": prior["total_tokens"] + prompt + completion,
        "last_turn_prompt": prompt,
        "last_turn_completion": completion,
    }


def test_accumulation_single_turn_with_provider_usage():
    """A single turn where the provider returns a usage block:
    lifetime totals = the turn's usage, last_turn_* = the same."""
    prior = {
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "total_tokens": 0,
        "last_turn_prompt": 0,
        "last_turn_completion": 0,
    }
    out = _accumulate(prior, prompt=12, completion=88)
    assert out["prompt_tokens"] == 12
    assert out["completion_tokens"] == 88
    assert out["total_tokens"] == 100
    assert out["last_turn_prompt"] == 12
    assert out["last_turn_completion"] == 88


def test_accumulation_multi_turn_totals_additive_last_turn_resets():
    """Three turns: lifetime totals add, last_turn_* resets to the
    most recent turn's values."""
    prior = {
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "total_tokens": 0,
        "last_turn_prompt": 0,
        "last_turn_completion": 0,
    }
    prior = _accumulate(prior, prompt=10, completion=20)
    prior = _accumulate(prior, prompt=15, completion=25)
    prior = _accumulate(prior, prompt=20, completion=30)
    assert prior["prompt_tokens"] == 45  # 10 + 15 + 20
    assert prior["completion_tokens"] == 75  # 20 + 25 + 30
    assert prior["total_tokens"] == 120
    assert prior["last_turn_prompt"] == 20  # most recent
    assert prior["last_turn_completion"] == 30


def test_accumulation_mock_llm_zero_usage():
    """The mock LLM never sets `StreamChunk.usage`, so the handler
    uses the v1.2.0 char/4 estimate. The accumulation must still
    work — `prompt_tokens` ends at 0 and `completion_tokens` is
    the sum of the per-turn estimates."""
    prior = {
        "prompt_tokens": 0,
        "completion_tokens": 0,
        "total_tokens": 0,
        "last_turn_prompt": 0,
        "last_turn_completion": 0,
    }
    # 400-char response → 100 completion tokens (400/4).
    prior = _accumulate(prior, prompt=0, completion=100)
    prior = _accumulate(prior, prompt=0, completion=200)
    assert prior["prompt_tokens"] == 0
    assert prior["completion_tokens"] == 300
    assert prior["total_tokens"] == 300
    assert prior["last_turn_prompt"] == 0
    assert prior["last_turn_completion"] == 200
