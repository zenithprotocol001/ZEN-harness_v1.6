"""Tests for scripts/migrate_v03_to_v04.py (ADR-0014).

The migration script reads v0x03 entries from a JSONL log and
re-seals them as v0x04. The script:
- reads with `open_envelope(..., require_binding=False)`,
- **refuses to migrate anonymous v0x03 envelopes** (where the
  name is empty) because they are a downgrade vector,
- re-seals via the public `seal()` (which writes v0x04),
- writes the new log atomically (tmp + rename),
- preserves the old log at `<log>.v03.bak`,
- is idempotent.
"""
from __future__ import annotations

import base64
import json
from pathlib import Path

import pytest

from dhc.cordis.secrets import (
    HEADER_V3,
    HEADER_V4,
    SecretEnvelopeError,
    _seal_with,
    open_envelope,
    seal,
)

from scripts import migrate_v03_to_v04


MASTER = b"k" * 32


def _plant_v03_entry(dir_: Path, name: str, value: bytes) -> None:
    """Plant a v0x03 envelope in <dir_>/secrets.log with a matching
    secrets.key file. The envelope is sealed with `_seal_with` so
    the test fully controls the wire format.
    """
    dir_.mkdir(parents=True, exist_ok=True)
    (dir_ / "secrets.key").write_bytes(MASTER)
    blob = _seal_with(value, MASTER, HEADER_V3, name=name.encode("utf-8"))
    rec = {"op": "set", "name": name, "blob": base64.b64encode(blob).decode("ascii")}
    (dir_ / "secrets.log").write_text(
        json.dumps(rec, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )


# ---------- 1. migration success: v0x03 → v0x04 ----------


def test_migrate_v03_to_v04_success(tmp_path: Path):
    """A non-anonymous v0x03 envelope is migrated to v0x04. The
    new log has the same name; the envelope is now `DHC4`.
    """
    src = tmp_path / "src"
    _plant_v03_entry(src, "openai_api_key", b"sk-test-1234567890")
    n = migrate_v03_to_v04.migrate(src)
    assert n == 1
    # The new log has the same name; the envelope is now DHC4.
    log_text = (src / "secrets.log").read_text(encoding="utf-8")
    rec = json.loads(log_text.strip().splitlines()[0])
    blob = base64.b64decode(rec["blob"])
    assert blob[:4] == HEADER_V4
    assert rec["name"] == "openai_api_key"
    # Round-trip: open the v0x04 envelope with the same name.
    assert open_envelope(blob, MASTER, name=b"openai_api_key") == b"sk-test-1234567890"
    # The old log is preserved at <log>.v03.bak.
    assert (src / "secrets.log.v03.bak").exists()


# ---------- 2. migration refuses anonymous v0x03 envelopes ----------


def test_migrate_refuses_anonymous_v03(tmp_path: Path):
    """A v0x03 envelope sealed with `name=b""` is a downgrade
    vector. The migration script raises.
    """
    src = tmp_path / "anon"
    src.mkdir(parents=True, exist_ok=True)
    (src / "secrets.key").write_bytes(MASTER)
    blob = _seal_with(b"anonymous value", MASTER, HEADER_V3, name=b"")
    rec = {"op": "set", "name": "", "blob": base64.b64encode(blob).decode("ascii")}
    (src / "secrets.log").write_text(
        json.dumps(rec, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )
    with pytest.raises(SecretEnvelopeError) as excinfo:
        migrate_v03_to_v04.migrate(src)
    assert "refusing to migrate anonymous" in str(excinfo.value)


# ---------- 3. migration is idempotent ----------


def test_migrate_is_idempotent(tmp_path: Path):
    """Running the migration twice is a no-op. After the first
    run, no v0x03 envelopes remain. The second run migrates
    zero entries.
    """
    src = tmp_path / "src"
    _plant_v03_entry(src, "k1", b"v1")
    n1 = migrate_v03_to_v04.migrate(src)
    assert n1 == 1
    n2 = migrate_v03_to_v04.migrate(src)
    assert n2 == 0
    # The log is still correct.
    log_text = (src / "secrets.log").read_text(encoding="utf-8")
    rec = json.loads(log_text.strip().splitlines()[0])
    blob = base64.b64decode(rec["blob"])
    assert blob[:4] == HEADER_V4


# ---------- 4. migration preserves the old log ----------


def test_migrate_preserves_old_log(tmp_path: Path):
    """The original log is preserved at `<log>.v03.bak`. This
    is the safety net in case the migration produces a corrupt
    log: the user can recover by restoring the backup.
    """
    src = tmp_path / "src"
    _plant_v03_entry(src, "k1", b"v1")
    # The original log exists at the start.
    original = (src / "secrets.log").read_bytes()
    migrate_v03_to_v04.migrate(src)
    # The backup contains the original bytes.
    backup = (src / "secrets.log.v03.bak").read_bytes()
    assert backup == original
    # The new log has been re-written with v0x04.
    new = (src / "secrets.log").read_bytes()
    assert new != original
    rec = json.loads(new.decode("utf-8").strip().splitlines()[0])
    blob = base64.b64decode(rec["blob"])
    assert blob[:4] == HEADER_V4
