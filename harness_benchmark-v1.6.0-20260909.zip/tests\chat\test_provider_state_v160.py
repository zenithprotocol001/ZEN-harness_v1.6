"""v1.6.0 tests for ProviderStateManager + /api/settings/state.

Verifies:
- ProviderStateManager.update / get / snapshot / clear.
- HealthStatus is a closed enum.
- /api/settings/state redacts the key (never echoes raw value).
- /api/settings/state includes ref_hint for env sources.
- /api/settings/state includes health from a prior probe.
- /api/settings/state marks unconfigured providers as "not_set".
- /api/settings/state drops unknown provider ids.
- /api/settings/state never logs the key in the response.
"""
from __future__ import annotations

import asyncio
import json
import os
import tempfile
from pathlib import Path

import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

from dhc.cordis.context import Context
from dhc.cordis.secrets import SecretSource, SecretSourceType, SecretsService
from dhc.modules.c1_gui_web_core.service import GuiWebCore
from dhc.services.provider_state import (
    HealthStatus,
    ProviderState,
    ProviderStateManager,
)


def test_health_status_is_closed_enum() -> None:
    members = set(HealthStatus.__members__.keys())
    assert members == {"unknown", "valid", "invalid", "network_error", "not_supported"}


def test_provider_state_default_is_unknown() -> None:
    s = ProviderState()
    assert s.present is False
    assert s.health_status is HealthStatus.unknown
    assert s.health_label is None
    assert s.last_check_at == 0.0


def test_provider_state_manager_update_get() -> None:
    m = ProviderStateManager()
    m.update("openrouter", present=True, source=SecretSourceType.raw,
             health=HealthStatus.valid, label="My Label")
    s = m.get("openrouter")
    assert s.present is True
    assert s.health_status is HealthStatus.valid
    assert s.health_label == "My Label"
    assert s.last_check_at > 0.0


def test_provider_state_manager_get_missing_returns_default() -> None:
    m = ProviderStateManager()
    s = m.get("nonexistent")
    assert s.present is False
    assert s.health_status is HealthStatus.unknown


def test_provider_state_manager_snapshot() -> None:
    m = ProviderStateManager()
    m.update("openrouter", present=True, source=SecretSourceType.raw,
             health=HealthStatus.valid, label="L1")
    m.update("openai", present=True, source=SecretSourceType.env,
             health=HealthStatus.invalid)
    snap = m.snapshot()
    assert set(snap.keys()) == {"openrouter", "openai"}
    assert snap["openrouter"].health_label == "L1"
    assert snap["openai"].health_status is HealthStatus.invalid


def test_provider_state_manager_clear() -> None:
    m = ProviderStateManager()
    m.update("openrouter", present=True, source=SecretSourceType.raw,
             health=HealthStatus.valid, label="X")
    m.clear("openrouter")
    s = m.get("openrouter")
    assert s.health_status is HealthStatus.unknown


def _build_web_core(
    secrets_dir: Path,
    *,
    sessions_dir: Path | None = None,
) -> GuiWebCore:
    gwc = GuiWebCore(
        host="127.0.0.1",
        port=0,
        secrets_dir=str(secrets_dir),
        sessions_dir=str(sessions_dir) if sessions_dir else None,
        require_token=False,
    )
    return gwc


@pytest.fixture
def web_core_with_secrets(tmp_path: Path):
    secrets_dir = tmp_path / "secrets"
    sessions_dir = tmp_path / "sessions"
    secrets_dir.mkdir()
    sessions_dir.mkdir()
    gwc = _build_web_core(secrets_dir, sessions_dir=sessions_dir)
    gwc.app["ctx"] = Context()
    return gwc, secrets_dir, sessions_dir


def test_settings_state_empty_returns_not_set(web_core_with_secrets) -> None:
    gwc, _, _ = web_core_with_secrets
    # The handler is async; call it via the test client.
    async def _run() -> None:
        async with TestClient(TestServer(gwc.app)) as client:
            r = await client.get("/api/settings/state")
            assert r.status == 200
            data = await r.json()
            assert "providers" in data
            for p, entry in data["providers"].items():
                assert entry["status"] == "not_set"
                assert entry["hint"] is None
                assert entry["health"] in {h.value for h in HealthStatus}

    asyncio.run(_run())


def test_settings_state_raw_source_marks_configured(
    web_core_with_secrets,
) -> None:
    gwc, _, _ = web_core_with_secrets
    gwc.secrets_service.put_raw("llm_provider_openrouter_auto", b"sk-or-v1-1234567890abcd")
    # Simulate a prior probe writing the cache.
    gwc.provider_state.update(
        "openrouter", present=True, source=SecretSourceType.raw,
        health=HealthStatus.valid, label="User's Label",
    )

    async def _run() -> None:
        async with TestClient(TestServer(gwc.app)) as client:
            r = await client.get("/api/settings/state")
            assert r.status == 200
            data = await r.json()
            openrouter = data["providers"]["openrouter"]
            assert openrouter["status"] == "configured"
            assert openrouter["source"] == "raw"
            assert openrouter["hint"] == "…abcd"
            assert openrouter["health"] == "valid"
            assert openrouter["health_label"] == "User's Label"
            # CRITICAL: the raw key value is NEVER in the response.
            raw = await r.read()
            assert b"sk-or-v1-1234567890abcd" not in raw

    asyncio.run(_run())


def test_settings_state_env_source_includes_ref_hint(
    web_core_with_secrets, monkeypatch: pytest.MonkeyPatch,
) -> None:
    gwc, _, _ = web_core_with_secrets
    monkeypatch.setenv("DHC_TEST_PROVIDER_KEY", "abc12345")
    gwc.secrets_service.put_source(
        "llm_provider_openrouter_auto",
        SecretSource(type=SecretSourceType.env, ref="DHC_TEST_PROVIDER_KEY"),
    )
    gwc.provider_state.update(
        "openrouter", present=True, source=SecretSourceType.env,
        health=HealthStatus.unknown,
    )

    async def _run() -> None:
        async with TestClient(TestServer(gwc.app)) as client:
            r = await client.get("/api/settings/state")
            data = await r.json()
            openrouter = data["providers"]["openrouter"]
            assert openrouter["status"] == "configured"
            assert openrouter["source"] == "env"
            # The env var name is shown (not the value).
            assert openrouter["ref_hint"] == "DHC_TEST_PROVIDER_KEY"
            # The v0x04 hint shows the last 4 of the resolved value.
            assert openrouter["hint"] == "…2345"
            # The env var value is NOT in the response.
            raw = await r.read()
            assert b"abc12345" not in raw
            # (The ref_hint IS in the response, by design — it
            # shows the user where the key came from.)

    asyncio.run(_run())


def test_settings_state_unknown_provider_dropped(
    web_core_with_secrets,
) -> None:
    gwc, _, _ = web_core_with_secrets
    # A stale secret name (e.g. a deleted model's key) must not
    # show up in the providers map.
    gwc.secrets_service.put_raw("llm_provider_defunct_provider_auto", b"x")

    async def _run() -> None:
        async with TestClient(TestServer(gwc.app)) as client:
            r = await client.get("/api/settings/state")
            data = await r.json()
            assert "defunct_provider" not in data["providers"]

    asyncio.run(_run())


def test_settings_state_includes_cached_health(
    web_core_with_secrets,
) -> None:
    """The /api/settings/state response reflects the
    ProviderStateManager cache. A user who has saved a key and
    then tested it sees the health badge without a new probe.
    """
    gwc, _, _ = web_core_with_secrets
    gwc.secrets_service.put_raw("llm_provider_openrouter_auto", b"sk-or-v1-9876543210zyxw")
    gwc.provider_state.update(
        "openrouter", present=True, source=SecretSourceType.raw,
        health=HealthStatus.invalid, label=None,
    )

    async def _run() -> None:
        async with TestClient(TestServer(gwc.app)) as client:
            r = await client.get("/api/settings/state")
            data = await r.json()
            openrouter = data["providers"]["openrouter"]
            assert openrouter["status"] == "configured"
            assert openrouter["health"] == "invalid"
            assert openrouter["health_label"] is None

    asyncio.run(_run())


def test_health_probe_writes_to_provider_state(
    web_core_with_secrets, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """End-to-end: a probe to /api/llm/health/openrouter writes
    to the ProviderStateManager. The next /api/settings/state
    reflects the new health without re-probing.
    """
    gwc, _, _ = web_core_with_secrets
    gwc.secrets_service.put_raw("llm_provider_openrouter_auto", b"sk-or-v1-11112222aaaa")

    # Pre-state: unknown.
    assert gwc.provider_state.get("openrouter").health_status is HealthStatus.unknown

    async def _run() -> None:
        async with TestClient(TestServer(gwc.app)) as client:
            # The probe will fail (no OpenRouter network in CI);
            # we only assert that the cache was updated to
            # network_error (or similar non-unknown), not that
            # the upstream returned a specific result.
            await client.get("/api/llm/health/openrouter")
            s = gwc.provider_state.get("openrouter")
            assert s.health_status is not HealthStatus.unknown
            # Verify /api/settings/state reflects the cached state.
            r = await client.get("/api/settings/state")
            data = await r.json()
            openrouter = data["providers"]["openrouter"]
            assert openrouter["health"] == s.health_status.value
            assert openrouter["last_check_at"] == pytest.approx(s.last_check_at, rel=1e-3)

    asyncio.run(_run())
