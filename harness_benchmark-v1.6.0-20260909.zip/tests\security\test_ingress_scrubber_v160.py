"""v1.6.0 tests for IngressScrubber.

Verifies the closed-enum regex pipeline redacts known provider
key prefixes from inbound user text. Pins the no-leak contract
at the WebSocket ingress boundary (verification Finding #1).
"""
from __future__ import annotations

import pytest

from dhc.security.ingress_scrubber import (
    PROVIDER_KEY_PATTERNS,
    REDACTED,
    ScrubResult,
    scrub,
)


def test_scrub_redacts_openrouter_key() -> None:
    s = scrub("my key is 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")
    assert s.redactions == 1
    assert "sk-or-v1-ee5a" not in s.text
    assert REDACTED in s.text
    assert s.text == "my key is [REDACTED_API_KEY]"


def test_scrub_redacts_anthropic_key() -> None:
    s = scrub("here is sk-ant-api03-abc123def456ghi789jkl012mno345pqr678stu901vwx234yz")
    assert s.redactions == 1
    assert "sk-ant-api03-abc" not in s.text
    assert REDACTED in s.text


def test_scrub_redacts_openai_project_key() -> None:
    s = scrub("key: sk-proj-abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOP")
    assert s.redactions == 1
    assert "sk-proj-" not in s.text
    assert REDACTED in s.text


def test_scrub_handles_multiple_keys_in_one_text() -> None:
    s = scrub(
        "first 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 "
        "and second sk-ant-api03-abc123def456ghi789jkl012mno345pqr678stu901vwx234yz"
    )
    assert s.redactions == 2
    assert "sk-or-v1-" not in s.text
    assert "sk-ant-" not in s.text
    assert s.text.count(REDACTED) == 2


def test_scrub_leaves_non_key_text_untouched() -> None:
    text = "Hello, please summarize the following article."
    s = scrub(text)
    assert s.redactions == 0
    assert s.text == text


def test_scrub_does_not_match_short_tokens() -> None:
    """The `sk-` prefix is intentionally NOT in PROVIDER_KEY_PATTERNS
    (it would false-positive on common words and URLs). The
    specific prefixes are `sk-or-v1-`, `sk-ant-`, `sk-proj-`,
    each with a 20+ char minimum. Pins the no-false-positive
    contract."""
    text = "sk-or-v1-short"  # too short to be a real key
    s = scrub(text)
    assert s.redactions == 0
    assert s.text == text


def test_scrub_does_not_match_url_with_sk_prefix() -> None:
    text = "see https://example.com/sk-or-v1-foo for details"
    s = scrub(text)
    # "sk-or-v1-foo" is only 3 chars after the dash; not a match.
    assert s.redactions == 0


def test_scrub_empty_string() -> None:
    s = scrub("")
    assert s.redactions == 0
    assert s.text == ""
    assert s.original_len == 0
    assert s.redacted_len == 0


def test_scrub_preserves_original_text_when_no_match() -> None:
    text = "This is a normal chat message with no secrets."
    s = scrub(text)
    assert s.text == text
    assert s.original_len == s.redacted_len == len(text)
    assert s.redactions == 0


def test_scrub_pattern_set_is_closed() -> None:
    """PROVIDER_KEY_PATTERNS is a closed tuple. A regression
    that adds a pattern (or removes one) is a kernel-visible
    change and must require an ADR. The test pins the current
    set."""
    assert len(PROVIDER_KEY_PATTERNS) == 3
    patterns_as_str = "\n".join(p.pattern for p in PROVIDER_KEY_PATTERNS)
    assert "sk-or-v1-" in patterns_as_str
    assert "sk-ant-" in patterns_as_str
    assert "sk-proj-" in patterns_as_str


def test_scrub_redaction_marker_is_stable() -> None:
    """The `[REDACTED_API_KEY]` marker must not change between
    releases. Frontend code and journal readers depend on the
    exact string for redacted-line detection."""
    assert REDACTED == "[REDACTED_API_KEY]"


def test_scrub_returns_scrubresult_dataclass() -> None:
    s = scrub("hello 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 world")
    assert isinstance(s, ScrubResult)
    assert s.redactions == 1
    # The redacted text is shorter than the original (the key
    # is replaced with a shorter marker).
    assert s.redacted_len < s.original_len
