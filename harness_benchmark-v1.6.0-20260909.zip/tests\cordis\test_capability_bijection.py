"""Capability bijection invariant tests (ADR-0015-amendment-1).

3 tests:

1. `test_cap_below_v150_cap`: the Capability enum is below the v1.5.0
   cap of 32 (property check; the invariant script reads the same
   shape).
2. `test_capability_whitelist_bijection`: the enum and the whitelist
   are in bijection. No orphan capabilities (in the enum but not in
   the whitelist). No dangling capabilities (in the whitelist but not
   in the enum).
3. `test_registered_capabilities_match_enum`: instantiates a real
   `GuiWebCore` and reads `self.registered_capabilities` after
   `_setup_routes` runs. The set is the runtime projection of the
   `@requires` calls. The invariant asserts
   `set(Capability) == web_core.registered_capabilities` — every
   capability must be reachable from a route, and every gated
   route must be a known capability.

A regression on any of these properties is a hard DoD failure.
"""
from __future__ import annotations

import tempfile
from pathlib import Path

from dhc.cordis.capabilities import (
    ACTION_WHITELIST,
    CAPABILITY_BUDGET_V150,
    Capability,
)
from dhc.modules.c1_gui_web_core.service import GuiWebCore


# ---------- 1. Cap property ----------


def test_cap_below_v150_cap() -> None:
    """The Capability enum is below the v1.5.0 cap of 32."""
    assert len(Capability) <= CAPABILITY_BUDGET_V150
    # And the v1.4.0 cap is preserved as archaeology.
    assert CAPABILITY_BUDGET_V150 == 32


# ---------- 2. Enum-whitelist bijection ----------


def test_capability_whitelist_bijection() -> None:
    """The Capability enum and ACTION_WHITELIST are in bijection."""
    enum_set = set(Capability)
    wl_set = set(ACTION_WHITELIST.keys())
    # No orphan capabilities (in the enum but not in the whitelist).
    assert enum_set == wl_set, (
        f"orphan: {enum_set - wl_set}; dangling: {wl_set - enum_set}"
    )
    # Whitelist values are all LOOPBACK (v1.5.0 single-tier harness).
    from dhc.cordis.capabilities import ActorTier
    for cap, tier in ACTION_WHITELIST.items():
        assert tier == ActorTier.LOOPBACK, (
            f"non-loopback tier for {cap.value}: {tier}"
        )


# ---------- 3. Runtime bijection (the new invariant) ----------


def test_registered_capabilities_match_enum() -> None:
    """`GuiWebCore.registered_capabilities` is in bijection with the
    Capability enum.

    Instantiates a real `GuiWebCore` against a tmp sessions dir,
    reads `self.registered_capabilities` after `_setup_routes` runs,
    and asserts:
        set(Capability) == web_core.registered_capabilities

    Until Phases 2 and 3 register the 6 new routes
    (3 branching + 3 attachments), the 6 new capabilities are in
    the enum but not on a route, so this assertion fails by design.
    """
    with tempfile.TemporaryDirectory() as td:
        sd = Path(td) / "sessions"
        sd.mkdir()
        gwc = GuiWebCore(sessions_dir=sd)
        enum_set = set(Capability)
        reg_set = gwc.registered_capabilities
        # Every gated route is a known capability (no dangling routes).
        assert reg_set <= enum_set, (
            f"dangling routes: {reg_set - enum_set}"
        )
        # Phases 2 and 3 must close the gap; the v1.5.0 release
        # asserts strict equality.
        missing = enum_set - reg_set
        assert not missing, (
            f"orphan capabilities (no route registered): "
            f"{sorted(c.value for c in missing)}"
        )
