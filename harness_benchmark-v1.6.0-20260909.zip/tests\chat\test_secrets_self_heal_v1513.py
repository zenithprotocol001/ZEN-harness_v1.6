"""v1.5.1.3 (audit hotfix #3) — SecretsService self-heal contract.

The `put_raw` and `delete` write paths must self-heal the
secrets directory. The constructor's `mkdir` only runs at
startup; if the dir is removed after startup (a prior test
cleanup, a manual `rm`, a migration that touched the dir),
the next `open("a")` raises `FileNotFoundError`. Re-creating
the parent on every write makes the path robust to any prior
state.

The lock is the same `self._lock` already held by `put_raw`
and `delete`, so concurrent writes still serialize — there
is no new lock to introduce. The
`test_concurrent_puts_dont_interleave` test pins this
contract: spawn N threads, each calling `put` M times,
assert the log file has N*M valid JSON lines (no partial
lines, no interleaved bytes).

These tests do not require a running aiohttp server; they
exercise `SecretsService` directly against a `tmp_path`.
"""
from __future__ import annotations

import json
import shutil
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from dhc.cordis.secrets import SecretsService


def test_put_raw_self_heals_missing_secrets_dir(tmp_path: Path) -> None:
    """If the secrets dir is removed after the constructor runs,
    the next `put_raw` must recreate the dir + log file and
    persist the record."""
    secrets_dir = tmp_path / "secrets"
    service = SecretsService(secrets_dir)
    assert secrets_dir.is_dir()

    # Simulate a post-startup state mutation (test cleanup,
    # manual `rm`, a migration that touched the dir).
    shutil.rmtree(secrets_dir)
    assert not secrets_dir.exists()

    # The v1.5.1.3 self-heal must not raise FileNotFoundError.
    service.put("openai_main", "sk-test-1234567890")

    # The dir + log file are recreated.
    assert secrets_dir.is_dir()
    assert (secrets_dir / "secrets.log").is_file()

    # The log contains exactly one set record.
    log = (secrets_dir / "secrets.log").read_text(encoding="utf-8")
    lines = [ln for ln in log.splitlines() if ln.strip()]
    assert len(lines) == 1
    parsed = json.loads(lines[0])
    assert parsed["op"] == "set"
    assert parsed["name"] == "openai_main"

    # Round-trip: `get` reads back the original value.
    assert service.get("openai_main") == "sk-test-1234567890"


def test_delete_self_heals_missing_secrets_dir(tmp_path: Path) -> None:
    """The `delete` path must also self-heal. After the dir is
    wiped, `put` + `delete` both recreate the dir and write
    the expected records.

    Note: `delete` calls `_replay()` first, which scans the log
    file from disk. If the log is missing, the cache is rebuilt
    empty and a `delete(name)` for a name that was only in
    cache pre-wipe returns `False`. To exercise the tombstone
    path we must re-`put` the name (which self-heals and adds
    it to the log), then `delete` it (which self-heals again
    and appends a tombstone)."""
    secrets_dir = tmp_path / "secrets"
    service = SecretsService(secrets_dir)

    # Wipe the dir before any write.
    shutil.rmtree(secrets_dir)
    assert not secrets_dir.exists()

    # First write self-heals; `put("k")` makes `k` resolvable.
    service.put("k", "v")
    assert service.get("k") == "v"

    # Wipe again to test `delete` self-heal in isolation.
    shutil.rmtree(secrets_dir)
    assert not secrets_dir.exists()

    # Re-`put` to re-seed the log (this also self-heals), then
    # `delete` to emit a tombstone (this also self-heals).
    service.put("k", "v")
    assert service.delete("k") is True

    # Two records: one `set` for k, one `del` for k.
    log = (secrets_dir / "secrets.log").read_text(encoding="utf-8")
    lines = [ln for ln in log.splitlines() if ln.strip()]
    assert len(lines) == 2
    parsed = [json.loads(ln) for ln in lines]
    assert parsed[0]["op"] == "set" and parsed[0]["name"] == "k"
    assert parsed[1]["op"] == "del" and parsed[1]["name"] == "k"


def test_self_heal_survives_full_state_wipe(tmp_path: Path) -> None:
    """A full `rmtree` between sessions must not brick the
    service. After the wipe, the service must still round-trip
    new values (old values are gone, the log is rebuilt from
    scratch)."""
    secrets_dir = tmp_path / "secrets"
    service = SecretsService(secrets_dir)

    # Round-trip some values.
    service.put("a", "alpha")
    service.put("b", "bravo")
    service.put("c", "charlie")
    assert service.get("a") == "alpha"
    assert service.get("b") == "bravo"
    assert service.get("c") == "charlie"

    # Wipe.
    shutil.rmtree(secrets_dir)

    # Round-trip a new value.
    service.put("d", "delta")
    assert service.get("d") == "delta"

    # The old values are gone (the cache was wiped, the log
    # is rebuilt from the single new record).
    log = (secrets_dir / "secrets.log").read_text(encoding="utf-8")
    lines = [ln for ln in log.splitlines() if ln.strip()]
    assert len(lines) == 1
    parsed = json.loads(lines[0])
    assert parsed["op"] == "set" and parsed["name"] == "d"


def test_self_heal_works_when_secrets_dir_never_existed_at_init(
    tmp_path: Path,
) -> None:
    """Simulate a fresh install: the dir is created by the
    constructor, then immediately rmtree'd, then the first
    write must still work (self-heal is the source of truth)."""
    secrets_dir = tmp_path / "secrets"
    service = SecretsService(secrets_dir)
    # Wipe the dir before the first write.
    shutil.rmtree(secrets_dir)
    # First write self-heals.
    service.put("k", "v")
    assert service.get("k") == "v"


def test_concurrent_puts_dont_interleave(tmp_path: Path) -> None:
    """Pins the v1.5.1.3 contract that `put_raw` and `delete`
    serialize via `self._lock`. Spawn N threads, each calling
    `put` M times, assert the log file has N*M valid JSON
    lines (no partial lines, no interleaved bytes)."""
    secrets_dir = tmp_path / "secrets"
    service = SecretsService(secrets_dir)

    n_threads = 4
    m_per_thread = 25
    barrier = threading.Barrier(n_threads)

    def worker(thread_id: int) -> None:
        # All threads start at the same time to maximize
        # contention.
        barrier.wait()
        for i in range(m_per_thread):
            service.put(f"k_t{thread_id}_i{i}", f"v_t{thread_id}_i{i}")

    with ThreadPoolExecutor(max_workers=n_threads) as ex:
        futs = [ex.submit(worker, t) for t in range(n_threads)]
        for f in futs:
            f.result()

    log = (secrets_dir / "secrets.log").read_text(encoding="utf-8")
    lines = [ln for ln in log.splitlines() if ln.strip()]
    assert len(lines) == n_threads * m_per_thread
    # Every line parses as JSON; no partial writes.
    for ln in lines:
        parsed = json.loads(ln)
        assert parsed["op"] == "set"
        assert parsed["name"].startswith("k_t")
    # Every (thread, i) pair is present.
    seen = {json.loads(ln)["name"] for ln in lines}
    for t in range(n_threads):
        for i in range(m_per_thread):
            assert f"k_t{t}_i{i}" in seen
