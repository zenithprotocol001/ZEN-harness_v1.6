"""v1.6.0 tests for SecretSource polymorphic JSONL schema.

Verifies:
- SecretSourceType is a closed enum (raw, env, file).
- SecretSource.resolve() handles all 3 source types and fails loud.
- put_source with raw produces the v1.5.1.4 record shape (back-compat).
- put_source with env/file produces the v1.6.0 polymorphic shape.
- get_source returns the structured source (env var name / file path / raw bytes).
- list_metadata still works (regression — the v1.5.1.x contract).
- A mixed log (v1.5.1.4 records + v1.6.0 records) replays correctly.
- Tombstones still work.
- The on-disk envelope is always sealed regardless of source type.
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import pytest

from dhc.cordis.secrets import (
    SecretSource,
    SecretSourceError,
    SecretSourceType,
    SecretsService,
)


def test_secret_source_type_is_closed_enum() -> None:
    """SecretSourceType is a closed enum; new source types require
    a kernel ADR. Pins the bounded-entropy contract."""
    members = set(SecretSourceType.__members__.keys())
    assert members == {"raw", "env", "file"}


def test_secret_source_resolve_raw() -> None:
    s = SecretSource(type=SecretSourceType.raw, ref=None, value=b"hello")
    assert s.resolve() == b"hello"


def test_secret_source_resolve_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DHC_TEST_VAR", "from-env-var")
    s = SecretSource(type=SecretSourceType.env, ref="DHC_TEST_VAR", value=None)
    assert s.resolve() == b"from-env-var"


def test_secret_source_resolve_env_missing_fails_loud(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("DHC_TEST_VAR_DOES_NOT_EXIST", raising=False)
    s = SecretSource(type=SecretSourceType.env, ref="DHC_TEST_VAR_DOES_NOT_EXIST", value=None)
    with pytest.raises(SecretSourceError) as ei:
        s.resolve()
    assert "not set" in str(ei.value)


def test_secret_source_resolve_file() -> None:
    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        f.write(b"from-file-12345")
        path = f.name
    try:
        s = SecretSource(type=SecretSourceType.file, ref=path, value=None)
        assert s.resolve() == b"from-file-12345"
    finally:
        os.unlink(path)


def test_secret_source_resolve_file_missing_fails_loud() -> None:
    s = SecretSource(
        type=SecretSourceType.file, ref="/nonexistent/path/to/key", value=None
    )
    with pytest.raises(SecretSourceError) as ei:
        s.resolve()
    assert "not a file" in str(ei.value)


def test_secret_source_ref_hint() -> None:
    env_src = SecretSource(type=SecretSourceType.env, ref="OPENROUTER_API_KEY")
    assert env_src.ref_hint() == "OPENROUTER_API_KEY"
    file_src = SecretSource(type=SecretSourceType.file, ref="/home/user/.ssh/openrouter.key")
    assert file_src.ref_hint() == "openrouter.key"
    raw_src = SecretSource(type=SecretSourceType.raw, ref=None, value=b"x")
    assert raw_src.ref_hint() is None


def test_put_source_raw_produces_v1514_shape() -> None:
    """v1.6.0 must remain backward-compatible: a `raw` source
    produces the v1.5.1.4 record shape (no `source` field)."""
    with tempfile.TemporaryDirectory() as td:
        ss = SecretsService(Path(td))
        ss.put_source("test_key", SecretSource(type=SecretSourceType.raw, value=b"hello"))
        with open(ss._log, "r", encoding="utf-8") as f:
            rec = json.loads(f.readline())
        assert rec["op"] == "set"
        assert rec["name"] == "test_key"
        assert "blob" in rec
        # v1.5.1.4 compat: no `source` field for raw.
        assert "source" not in rec


def test_put_source_env_produces_v160_polymorphic_shape(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DHC_TEST_ENV_FOR_SHAPE", "abc123")
    with tempfile.TemporaryDirectory() as td:
        ss = SecretsService(Path(td))
        ss.put_source(
            "test_key",
            SecretSource(type=SecretSourceType.env, ref="DHC_TEST_ENV_FOR_SHAPE"),
        )
        with open(ss._log, "r", encoding="utf-8") as f:
            rec = json.loads(f.readline())
        assert rec["op"] == "set"
        assert rec["name"] == "test_key"
        assert rec["source"] == "env"
        assert rec["ref"] == "DHC_TEST_ENV_FOR_SHAPE"
        assert rec["ref_hint"] == "DHC_TEST_ENV_FOR_SHAPE"
        # Defense in depth: the envelope is still present.
        assert "blob" in rec
        # The blob is sealed; the env var name is NOT in the blob.
        assert b"DHC_TEST_ENV_FOR_SHAPE" not in rec["blob"].encode("ascii")


def test_put_source_file_produces_v160_polymorphic_shape() -> None:
    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        f.write(b"file-secret-value")
        path = f.name
    try:
        with tempfile.TemporaryDirectory() as td:
            ss = SecretsService(Path(td))
            ss.put_source(
                "test_key", SecretSource(type=SecretSourceType.file, ref=path)
            )
            with open(ss._log, "r", encoding="utf-8") as f:
                rec = json.loads(f.readline())
            assert rec["source"] == "file"
            assert rec["ref"] == path
            assert rec["ref_hint"] == os.path.basename(path)
            assert "blob" in rec
    finally:
        os.unlink(path)


def test_get_source_returns_structured_source(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DHC_GET_TEST", "env-value")
    with tempfile.TemporaryDirectory() as td:
        ss = SecretsService(Path(td))
        ss.put_source("raw_k", SecretSource(type=SecretSourceType.raw, value=b"raw-value"))
        ss.put_source("env_k", SecretSource(type=SecretSourceType.env, ref="DHC_GET_TEST"))
        assert ss.get_source("raw_k") == SecretSource(
            type=SecretSourceType.raw, ref=None, value=b"raw-value"
        )
        assert ss.get_source("env_k") == SecretSource(
            type=SecretSourceType.env, ref="DHC_GET_TEST", value=None
        )
        assert ss.get_source("missing") is None


def test_get_source_legacy_record_treated_as_raw() -> None:
    """A record written by v1.5.1.4 (no `source` field) must be
    readable as a raw source by v1.6.0. This is the migration
    path: existing logs replay unchanged."""
    with tempfile.TemporaryDirectory() as td:
        ss = SecretsService(Path(td))
        ss.put_raw("legacy", b"legacy-value")
        src = ss.get_source("legacy")
        assert src is not None
        assert src.type is SecretSourceType.raw
        assert src.value == b"legacy-value"


def test_list_metadata_works_with_mixed_log(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Mixed log (v1.5.1.4 raw + v1.6.0 env) — `list_metadata`
    must return the same shape regardless of source type."""
    monkeypatch.setenv("DHC_LIST_TEST", "from-env")
    with tempfile.TemporaryDirectory() as td:
        ss = SecretsService(Path(td))
        ss.put_raw("raw_k", b"raw-value-7890")
        ss.put_source(
            "env_k", SecretSource(type=SecretSourceType.env, ref="DHC_LIST_TEST")
        )
        meta = {m["name"]: m for m in ss.list_metadata()}
        assert meta["raw_k"]["hint"] == "…7890"
        # env_k: the value resolved from the env var is "from-env"
        # (8 bytes), so the last 4 are "n-env". The hint is the
        # v0x04 contract `…+last_4`. The env var name is NOT leaked
        # in the hint.
        assert meta["env_k"]["hint"] == "…-env"
        assert "DHC_LIST_TEST" not in meta["env_k"]["hint"]


def test_tombstone_works_for_polymorphic_records(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DHC_TOMB", "to-be-deleted")
    with tempfile.TemporaryDirectory() as td:
        ss = SecretsService(Path(td))
        ss.put_source("t_k", SecretSource(type=SecretSourceType.env, ref="DHC_TOMB"))
        assert ss.get_raw("t_k") == b"to-be-deleted"
        assert ss.delete("t_k") is True
        assert ss.get_raw("t_k") is None
        assert ss.get_source("t_k") is None
        assert ss.delete("t_k") is False  # idempotent


def test_put_source_rejects_invalid_source_type() -> None:
    with tempfile.TemporaryDirectory() as td:
        ss = SecretsService(Path(td))
        with pytest.raises(TypeError):
            ss.put_source("x", "not-a-SecretSource")  # type: ignore[arg-type]


def test_put_source_env_with_missing_var_fails_loud(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The PUT fails loud at write time, not at read time. This
    is the v1.6.0 contract: an env source with a missing env var
    raises SecretSourceError before any record is written."""
    monkeypatch.delenv("DHC_MISSING_FOR_PUT", raising=False)
    with tempfile.TemporaryDirectory() as td:
        ss = SecretsService(Path(td))
        with pytest.raises(SecretSourceError):
            ss.put_source(
                "k",
                SecretSource(type=SecretSourceType.env, ref="DHC_MISSING_FOR_PUT"),
            )
        # The log is empty (or contains only a prior record).
        if ss._log.exists():
            lines = ss._log.read_text(encoding="utf-8").splitlines()
            assert all(json.loads(l).get("name") != "k" for l in lines if l.strip())


def test_put_source_env_with_unreadable_file_fails_loud() -> None:
    with tempfile.TemporaryDirectory() as td:
        ss = SecretsService(Path(td))
        with pytest.raises(SecretSourceError):
            ss.put_source(
                "k",
                SecretSource(type=SecretSourceType.file, ref="/nonexistent/path"),
            )
