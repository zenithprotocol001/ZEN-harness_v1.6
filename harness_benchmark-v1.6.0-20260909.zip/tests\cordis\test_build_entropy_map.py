"""Tests for scripts/build_entropy_map.py.

2 tests covering:
1. The build script writes the GENERATED_MARKER to the file.
2. The build script's output covers every capability in the
   whitelist.
"""
from __future__ import annotations

import importlib
import sys
from pathlib import Path

from dhc.cordis.capabilities import ACTION_WHITELIST
from dhc.cordis.entropy_map import GENERATED_MARKER


REPO = Path(__file__).resolve().parents[2]


def test_build_writes_marker(tmp_path: Path, monkeypatch):
    """The build script writes the GENERATED_MARKER on line 1 of
    docs/entropy-map.md. A hand-edit is detected at invariant time.
    """
    # Redirect REPO so the build script writes to a temp dir.
    fake_repo = tmp_path / "fake_repo"
    fake_docs = fake_repo / "docs"
    fake_docs.mkdir(parents=True)
    # Patch the REPO constant in the build script module.
    if "scripts.build_entropy_map" in sys.modules:
        del sys.modules["scripts.build_entropy_map"]
    mod = importlib.import_module("scripts.build_entropy_map")
    monkeypatch.setattr(mod, "REPO", fake_repo)
    rc = mod.main()
    assert rc == 0
    out = fake_repo / "docs" / "entropy-map.md"
    assert out.exists()
    first_line = out.read_text(encoding="utf-8").splitlines()[0].strip()
    assert first_line == GENERATED_MARKER.strip()


def test_build_output_covers_every_capability():
    """The build script's output (the live docs/entropy-map.md) covers
    every capability in the whitelist.
    """
    live = REPO / "docs" / "entropy-map.md"
    assert live.exists(), "run scripts/build_entropy_map.py first"
    text = live.read_text(encoding="utf-8")
    for cap in ACTION_WHITELIST.keys():
        assert f"`{cap.value}`" in text
