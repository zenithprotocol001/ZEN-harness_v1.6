"""Tests for dhc.cordis.plugin_memory (v1.5.0.1).

The auto-load memory is the user's persistent opt-in list of
plugin ids. It lives at `~/.dhc/auto_load_plugins.json` (or a
caller-supplied path). The list is read on startup by `serve_c1`
and updated by the C1 service when the user loads or unloads a
plugin.

These tests cover the read/write/add/remove contract and the
malformed-file resilience.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from dhc.cordis.plugin_memory import PluginMemory


@pytest.fixture
def mem(tmp_path: Path) -> PluginMemory:
    return PluginMemory(tmp_path / "auto_load_plugins.json")


# ---------- 1. Empty / missing file ----------


def test_missing_file_returns_empty(mem: PluginMemory) -> None:
    """A missing memory file means the user has opted in to nothing."""
    assert mem.read() == []


# ---------- 2. Round-trip on a written list ----------


def test_write_then_read_round_trip(mem: PluginMemory) -> None:
    """A written list round-trips through `read`.

    `write` dedupes; the on-disk order is whatever the caller
    provided (post-dedup). `read` returns the same order.
    """
    mem.write(["rate_limiter_v1", "prompt_browser_v1"])
    assert mem.read() == ["rate_limiter_v1", "prompt_browser_v1"]
    # A different input order is preserved.
    mem.write(["prompt_browser_v1", "rate_limiter_v1"])
    assert mem.read() == ["prompt_browser_v1", "rate_limiter_v1"]


def test_write_dedupes(mem: PluginMemory) -> None:
    """`write` deduplicates; the first occurrence wins."""
    mem.write(["a", "b", "a", "c", "b"])
    assert mem.read() == ["a", "b", "c"]


# ---------- 3. add / remove / idempotency ----------


def test_add_appends(mem: PluginMemory) -> None:
    """`add` is idempotent; duplicates are silently dropped.
    The list preserves the order in which the user added the
    ids (first-added is first).
    """
    assert mem.add("rate_limiter_v1") == ["rate_limiter_v1"]
    assert mem.add("rate_limiter_v1") == ["rate_limiter_v1"]
    assert mem.add("prompt_browser_v1") == [
        "rate_limiter_v1",
        "prompt_browser_v1",
    ]
    # Adding an id that was already in the list is a no-op;
    # the *position* of the original entry is preserved.
    assert mem.add("rate_limiter_v1") == [
        "rate_limiter_v1",
        "prompt_browser_v1",
    ]


def test_remove_is_idempotent(mem: PluginMemory) -> None:
    """`remove` is a no-op when the id is not present."""
    mem.write(["a", "b", "c"])
    assert mem.remove("missing") == ["a", "b", "c"]
    assert mem.remove("b") == ["a", "c"]
    assert mem.remove("b") == ["a", "c"]


# ---------- 4. Atomic write on a flaky filesystem ----------


def test_write_replaces_atomically(mem: PluginMemory) -> None:
    """`write` rewrites via `*.tmp` + `os.replace`; the target file
    always reflects either the previous list or the new list, never
    a partial state.
    """
    mem.write(["x"])
    # Read the previous file before overwriting.
    prev = mem._path.read_text(encoding="utf-8")
    mem.write(["y", "z"])
    new = mem._path.read_text(encoding="utf-8")
    assert "x" in prev and "y" not in prev
    assert "y" in new and "z" in new
    # And no `.tmp` file is left behind.
    leftover = list(mem._path.parent.glob(".auto_load_plugins.*.tmp"))
    assert leftover == []


# ---------- 5. Malformed file is non-fatal ----------


def test_malformed_file_returns_empty(mem: PluginMemory) -> None:
    """A malformed file (hand-edited, partially-written) returns
    an empty list. The user is back to the default; a console
    warning is the operator's signal to fix the file by hand.
    """
    mem._path.parent.mkdir(parents=True, exist_ok=True)
    mem._path.write_text("{ this is not json", encoding="utf-8")
    assert mem.read() == []


def test_wrong_shape_returns_empty(mem: PluginMemory) -> None:
    """A file that is JSON but not the expected shape returns []."""
    mem._path.parent.mkdir(parents=True, exist_ok=True)
    mem._path.write_text(json.dumps({"unrelated": "key"}), encoding="utf-8")
    assert mem.read() == []


def test_non_list_auto_load_returns_empty(mem: PluginMemory) -> None:
    """`auto_load` is required to be a list; anything else yields []."""
    mem._path.parent.mkdir(parents=True, exist_ok=True)
    mem._path.write_text(json.dumps({"auto_load": "not-a-list"}), encoding="utf-8")
    assert mem.read() == []
