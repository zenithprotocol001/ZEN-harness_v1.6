"""Tests for the Session model defaults (v1.3.2)."""
from __future__ import annotations

from dhc.services.session_manager import Session


def test_session_default_usage_totals_shape():
    s = Session(
        id="s_x",
        title="t",
        created_at=0,
        updated_at=0,
        messages=[],
    )
    # All five keys present, all zero.
    assert set(s.usage_totals.keys()) == {
        "prompt_tokens",
        "completion_tokens",
        "total_tokens",
        "last_turn_prompt",
        "last_turn_completion",
    }
    for v in s.usage_totals.values():
        assert v == 0
