"""Tests for dhc.cordis.secrets v0x03 envelope (ADR-0012).

The v0x03 envelope introduces extension blocks between the header
and the AEAD nonce. The first extension, type 0x0001, carries a
12-byte strict per-secret nonce. The scrypt KDF salt is
`strict_nonce (12) || aead_nonce (16)` = 28 bytes — two
independent random per-secret values.

Backward compatibility: v0x01 (DHC1) and v0x02 (DHC2) envelopes
remain readable. Unknown extension types in a v0x03 envelope are
silently skipped (forward compat).
"""
from __future__ import annotations

from pathlib import Path

import pytest

from dhc.cordis.secrets import (
    EXT_STRICT_NONCE,
    HEADER_V1,
    HEADER_V2,
    HEADER_V3,
    NONCE_LEN,
    STRICT_NONCE_LEN,
    SecretEnvelopeError,
    SecretsService,
    TAG_LEN,
    _parse_extensions,
    _pack_extension,
    _seal_with,
    _serialize_extensions,
    open_envelope,
    seal,
)


MASTER = b"k" * 32


# ---------- 1. v0x03 round-trip preserves plaintext ----------


def test_v3_round_trip_preserves_plaintext():
    """seal → open returns the original plaintext for the v0x03
    envelope, including at HMAC block boundaries."""
    for n in [0, 1, 15, 16, 17, 31, 32, 33, 100, 1024, 65536]:
        pt = bytes((i * 7 + 3) & 0xFF for i in range(n))
        # Pin to v0x03 explicitly; the public seal() defaults to v0x04
        # since v1.3.4 (ADR-0014).
        env = _seal_with(pt, MASTER, HEADER_V3, name=b"fixture")
        assert env[:4] == HEADER_V3
        assert open_envelope(env, MASTER, name=b"fixture") == pt


# ---------- 2. v0x03 extension is present and 12 bytes ----------


def test_v3_extension_strict_nonce_is_12_bytes():
    """The v0x03 envelope carries an EXT_STRICT_NONCE extension
    whose body is exactly 12 bytes (STRICT_NONCE_LEN)."""
    env = _seal_with(b"any plaintext", MASTER, HEADER_V3, name=b"fixture")
    assert env[:4] == HEADER_V3
    # Bytes 4..5 are the EXT_TOTAL length (uint16 BE).
    import struct
    ext_total = struct.unpack(">H", env[4:6])[0]
    # For v1.3.2 there is one extension of 12 bytes, so the area is
    # 4 (ext_len + ext_type) + 12 (body) = 16 bytes, plus the 2-byte
    # EXT_TOTAL = 18 bytes.
    assert ext_total == 4 + STRICT_NONCE_LEN
    # Parse the extension area: [EXT_TOTAL (2)][EXT_0_LEN (2)][EXT_0_TYPE (2)][EXT_0_BODY (12)]
    exts = _parse_extensions(env[4 : 6 + ext_total])
    assert EXT_STRICT_NONCE in exts
    assert len(exts[EXT_STRICT_NONCE]) == STRICT_NONCE_LEN


# ---------- 3. two v0x03 envelopes of the same plaintext differ ----------


def test_v3_strict_nonce_is_random_per_envelope():
    """Two v0x03 envelopes of the same plaintext produce different
    strict nonces. (And therefore different ciphertexts.)"""
    import struct
    pt = b"the same plaintext"
    e1 = _seal_with(pt, MASTER, HEADER_V3, name=b"fixture")
    e2 = _seal_with(pt, MASTER, HEADER_V3, name=b"fixture")
    assert e1 != e2
    # Pull the strict nonce from each envelope.
    def get_strict(env: bytes) -> bytes:
        ext_total = struct.unpack(">H", env[4:6])[0]
        exts = _parse_extensions(env[4 : 6 + ext_total])
        return exts[EXT_STRICT_NONCE]
    assert get_strict(e1) != get_strict(e2)
    # The AEAD nonces also differ (independent random draws).
    aead_off = 6 + struct.unpack(">H", e1[4:6])[0]
    assert e1[aead_off : aead_off + NONCE_LEN] != e2[aead_off : aead_off + NONCE_LEN]


# ---------- 4. v0x03 ciphertext differs from v0x02 ----------


def test_v3_ciphertext_differs_from_v2():
    """For the same plaintext, the v0x03 ciphertext bytes are not
    the v0x02 ciphertext bytes. This proves the strict nonce
    participates in the KDF (otherwise the two envelopes would
    differ only in the header byte and the extension area)."""
    pt = b"compare v02 and v03"
    e2 = _seal_with(pt, MASTER, HEADER_V2, name=b"fixture")
    e3 = _seal_with(pt, MASTER, HEADER_V3, name=b"fixture")
    # Strip the header (4 bytes) and the v0x03 extension area
    # (4 + 2 + STRICT_NONCE_LEN = 18 bytes), then compare ct.
    import struct
    e3_ext_total = struct.unpack(">H", e3[4:6])[0]
    # Both layouts: AEAD nonce is 16 bytes; ciphertext follows.
    e2_ct = e2[4 + NONCE_LEN : -TAG_LEN]
    e3_ct = e3[6 + e3_ext_total + NONCE_LEN : -TAG_LEN]
    assert e2_ct != e3_ct
    assert len(e2_ct) == len(e3_ct) == len(pt)


# ---------- 5. extension tampering fails the open ----------


def test_v3_extension_tampering_fails_open():
    """Flipping a bit in the strict-nonce extension body must
    change the KDF salt and the MAC input, causing the auth tag
    to mismatch. `open_envelope` raises `SecretEnvelopeError`."""
    import struct
    env = _seal_with(b"tamper me", MASTER, HEADER_V3, name=b"fixture")
    bad = bytearray(env)
    # The strict nonce body starts at offset 4 (header) + 2 (ext_total)
    # + 4 (ext_len + ext_type) = 10. Flip a bit.
    bad[10] ^= 0x01
    with pytest.raises(SecretEnvelopeError):
        open_envelope(bytes(bad), MASTER, name=b"fixture")


# ---------- 6. v0x01 still readable ----------


def test_v3_reader_handles_v1_envelope():
    """`open_envelope` still reads v0x01 (DHC1) envelopes. This
    is the backward-compatibility requirement for v1.2.0 / v1.3.0
    logs that pre-date v1.3.1."""
    env = _seal_with(b"legacy v0x01 secret", MASTER, HEADER_V1)
    assert env[:4] == HEADER_V1
    assert open_envelope(env, MASTER) == b"legacy v0x01 secret"


# ---------- 7. v0x02 still readable ----------


def test_v3_reader_handles_v2_envelope():
    """`open_envelope` still reads v0x02 (DHC2) envelopes. This
    is the backward-compatibility requirement for v1.3.1 logs."""
    env = _seal_with(b"v0x02 secret from v1.3.1", MASTER, HEADER_V2)
    assert env[:4] == HEADER_V2
    assert open_envelope(env, MASTER) == b"v0x02 secret from v1.3.1"


# ---------- 8. unknown extension type is preserved (forward compat) ----------


def test_v3_unknown_extension_type_is_preserved():
    """A v0x03 envelope with an extra, unknown extension type
    (e.g. 0x0002) round-trips through open_envelope. The reader
    must NOT reject unknown types — that's the forward-compat
    contract for v1.3.3+ extension types."""
    import struct
    strict = b"\x12" * STRICT_NONCE_LEN
    extra = b"v1.3.3 metadata payload"
    env = _seal_with(
        b"forward compat test",
        MASTER,
        HEADER_V3,
        extensions=[
            (EXT_STRICT_NONCE, strict),
            (0x0002, extra),  # unknown type, not in EXT_STRICT_NONCE
        ],
        name=b"forward-compat",
    )
    # Round-trip works (with name binding enforced, v1.3.3+).
    assert open_envelope(env, MASTER, name=b"forward-compat") == b"forward compat test"
    # The unknown extension is preserved on disk (we can re-parse
    # the area and find both extensions).
    ext_total = struct.unpack(">H", env[4:6])[0]
    exts = _parse_extensions(env[4 : 6 + ext_total])
    assert exts[EXT_STRICT_NONCE] == strict
    assert exts[0x0002] == extra
    # _serialize_extensions round-trips through _parse_extensions.
    again = _parse_extensions(_serialize_extensions([
        (EXT_STRICT_NONCE, strict),
        (0x0002, extra),
    ]))
    assert again == exts
    # _pack_extension packs a 4-byte header + body.
    assert _pack_extension(EXT_STRICT_NONCE, strict) == struct.pack(
        ">HH", STRICT_NONCE_LEN, EXT_STRICT_NONCE
    ) + strict
