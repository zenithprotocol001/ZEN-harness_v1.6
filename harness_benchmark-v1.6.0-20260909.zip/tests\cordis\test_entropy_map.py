"""Tests for the Entropy Map generator (ADR-0017).

2 tests covering:
1. The build marker is present at the top of the generated file.
2. The generated table covers every Capability in the whitelist.
"""
from __future__ import annotations

from pathlib import Path

from dhc.cordis.capabilities import ACTION_WHITELIST, Capability
from dhc.cordis.entropy_map import GENERATED_MARKER, render_entropy_map


REPO = Path(__file__).resolve().parents[2]
ENTROPY_MAP = REPO / "docs" / "entropy-map.md"


# ---------- 1. The build marker is present ----------


def test_entropy_map_marker_present():
    """The first line of docs/entropy-map.md is the GENERATED_MARKER.

    The build script writes the file. A hand-edit is detected by
    `scripts/invariants_check.ps1`.
    """
    assert ENTROPY_MAP.exists(), "docs/entropy-map.md does not exist; run scripts/build_entropy_map.py"
    content = ENTROPY_MAP.read_text(encoding="utf-8")
    # The first line is the marker.
    first_line = content.splitlines()[0].strip()
    assert first_line == GENERATED_MARKER.strip(), (
        f"first line is {first_line!r}, expected {GENERATED_MARKER!r}"
    )


# ---------- 2. The generated table covers every Capability ----------


def test_entropy_map_table_covers_every_capability():
    """Every Capability in ACTION_WHITELIST appears as a row in
    the Entropy Map. The audit doc cannot drift from the policy.
    """
    md = render_entropy_map()
    # The marker is the first line.
    assert md.splitlines()[0].strip() == GENERATED_MARKER.strip()
    # Every capability is mentioned in the doc (in the whitelist
    # table; the audit-surface inventory may also mention some of
    # them, which is fine).
    for cap in ACTION_WHITELIST.keys():
        # Markdown code-backtick form: `secret.put`.
        assert f"`{cap.value}`" in md, f"missing capability row: {cap.value}"
    # The whitelist table is the section between "## Capability
    # whitelist" and the next "## " heading. Property: the count
    # of pipe rows that start with "| `" (the table body) and
    # are inside the whitelist section equals the whitelist size.
    sections = md.split("## ")
    whitelist_section = next(
        s for s in sections if s.startswith("Capability whitelist")
    )
    whitelist_rows = sum(
        1 for line in whitelist_section.splitlines()
        if line.startswith("| `")
    )
    assert whitelist_rows == len(ACTION_WHITELIST), (
        f"whitelist table has {whitelist_rows} rows, expected {len(ACTION_WHITELIST)}"
    )
