"""Tests for dhc.cordis.pipeline_guard (the 5-stage CREC pipeline).

8 tests covering the full INGEST → AUTHORIZE → VALIDATE → EXECUTE
→ AUDIT flow. Each stage has a typed error; the pipeline surfaces
the error to the caller without re-wrapping it.
"""
from __future__ import annotations

import asyncio

import pytest

from dhc.cordis.capabilities import (
    ActorTier,
    Capability,
    CapabilityDenied,
)
from dhc.cordis.pipeline_guard import (
    AuditError,
    ExecutionError,
    NumberGateError,
    ValidationError,
    audit,
    authorize,
    execute,
    get_audit_log,
    ingest,
    reset_audit_log,
    run_pipeline,
    validate,
)


# ---------- 1. INGEST accepts bytes and str; rejects None ----------


def test_ingest_accepts_bytes_and_str():
    """The INGEST stage accepts bytes and str (lossless UTF-8
    encoding for str). None and other types raise NumberGateError.
    """
    assert ingest(b"hello") == b"hello"
    assert ingest("hello") == b"hello"
    with pytest.raises(NumberGateError):
        ingest(None)
    with pytest.raises(NumberGateError):
        ingest(12345)  # type: ignore[arg-type]


# ---------- 2. AUTHORIZE passes a whitelisted capability; denies others ----------


def test_authorize_passes_whitelisted_capability():
    """The AUTHORIZE stage returns the Capability for an
    authorized actor and raises CapabilityDenied otherwise.
    """
    cap = authorize(Capability.SECRET_PUT)
    assert cap is Capability.SECRET_PUT
    with pytest.raises(CapabilityDenied):
        authorize(Capability.SECRET_PUT, actor="stub_unauthorized_tier")


# ---------- 3. VALIDATE passes a valid payload; raises ValidationError otherwise ----------


def test_validate_passes_valid_payload():
    """The VALIDATE stage returns the validated payload or raises
    ValidationError.
    """

    def v(payload: bytes) -> bytes:
        if not payload:
            raise ValueError("empty payload")
        return payload.upper()

    assert validate(b"hello", v) == b"HELLO"
    with pytest.raises(ValidationError):
        validate(b"", v)


# ---------- 4. EXECUTE returns the handler's result; bubbles domain errors ----------


def test_execute_returns_handler_result():
    """The EXECUTE stage awaits the handler and returns the result.
    Domain errors bubble up unwrapped.
    """

    async def handler(_validated):
        return {"status": "ok"}

    result = asyncio.run(execute(b"data", handler))
    assert result == {"status": "ok"}


def test_execute_bubbles_handler_errors():
    """The EXECUTE stage does not wrap domain errors. The caller
    catches them with their original type.
    """

    class MyDomainError(Exception):
        pass

    async def handler(_validated):
        raise MyDomainError("boom")

    with pytest.raises(MyDomainError):
        asyncio.run(execute(b"data", handler))


# ---------- 5. AUDIT appends a 62-code projection; in-memory payload is lossless ----------


def test_audit_appends_projection():
    """The AUDIT stage appends a 62-code projection of the
    payload to the audit log. The in-memory payload is unchanged.
    """
    reset_audit_log()
    payload = b"hello, world!"  # comma + space + exclamation are non-legal
    audit(Capability.CHAT_SEND, payload, result={"ok": True})
    log = get_audit_log()
    assert len(log) == 1
    entry = log[0]
    assert entry["capability"] == "chat.send"
    # The audit_text is the strict projection: comma, space, exclamation escaped.
    assert "hello" in entry["audit_text"]
    assert "#0x2C" in entry["audit_text"]  # comma
    assert "#0x20" in entry["audit_text"]  # space
    assert "#0x21" in entry["audit_text"]  # exclamation
    # The original payload is not in the audit_text.
    assert "hello, world!" not in entry["audit_text"]


# ---------- 6. End-to-end pipeline success ----------


def test_end_to_end_pipeline_success():
    """The full pipeline runs INGEST → AUTHORIZE → VALIDATE →
    EXECUTE → AUDIT and returns the handler's result.
    """

    def v(payload: bytes) -> bytes:
        return payload.upper()

    async def handler(_validated):
        return {"echo": _validated.decode("utf-8"), "status": "ok"}

    reset_audit_log()
    result = asyncio.run(
        run_pipeline(
            data=b"hello, world!",
            capability=Capability.CHAT_SEND,
            validator=v,
            handler=handler,
            actor=ActorTier.LOOPBACK,
        )
    )
    assert result == {"echo": "HELLO, WORLD!", "status": "ok"}
    log = get_audit_log()
    assert len(log) == 1
    assert log[0]["capability"] == "chat.send"


# ---------- 7. Pipeline surfaces the typed error from each stage ----------


async def _async_identity(x):
    return x


@pytest.mark.parametrize(
    "data,capability,validator,handler,actor,exc_type",
    [
        (None, Capability.CHAT_SEND, lambda x: x, _async_identity, None, NumberGateError),
        (b"hi", Capability.CHAT_SEND, lambda x: (_ for _ in ()).throw(ValueError("bad")), _async_identity, None, ValidationError),
    ],
    ids=["ingest_none", "validate_raises"],
)
def test_pipeline_surfaces_typed_errors(data, capability, validator, handler, actor, exc_type):
    """The pipeline surfaces the typed error from each stage.

    Note: the AUTHORIZE stage's CapabilityDenied is exercised by
    test_capability_runtime_enforcement; the EXECUTE stage's
    ExecutionError is exercised by test_execute_bubbles_handler_errors
    (domain errors bubble up unwrapped, so we don't wrap them in
    ExecutionError in this v1.4.0 cut).
    """
    reset_audit_log()
    with pytest.raises(exc_type):
        asyncio.run(
            run_pipeline(
                data=data,
                capability=capability,
                validator=validator,
                handler=handler,
                actor=actor,
            )
        )


# ---------- 8. Audit emit is mandatory on success; the audit log is non-empty ----------


def test_audit_log_non_empty_after_success():
    """A successful pipeline run appends exactly one audit entry."""
    reset_audit_log()

    async def handler(_v):
        return "ok"

    asyncio.run(
        run_pipeline(
            data=b"x",
            capability=Capability.SESSION_LIST,
            validator=lambda x: x,
            handler=handler,
            actor=ActorTier.LOOPBACK,
        )
    )
    log = get_audit_log()
    assert len(log) == 1
    assert log[0]["capability"] == "session.list"
