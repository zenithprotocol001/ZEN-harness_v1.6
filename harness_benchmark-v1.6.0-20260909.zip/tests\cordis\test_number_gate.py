"""Tests for dhc.cordis.number_gate (ADR-0016, ADR-0017).

6 tests covering:
1. `LEGAL_TEXT_CODES` is exactly 62 codes (`[A-Z a-z 0-9]`).
2. The 256-code sweep: every byte code 0..255; the 62 legal codes
   pass as text, the other 194 are escaped.
3. Lossless roundtrip: `from_codes(to_codes(x), strict=False) == x`
   for arbitrary bytes.
4. Render-strict replaces non-legal bytes with `#0xNN` escapes.
5. Audit emit uses strict=True (the audit-render filter).
6. Provider boundary uses strict=False (lossless reconstruction).
"""
from __future__ import annotations

import pytest

from dhc.cordis.number_gate import (
    LEGAL_TEXT_CODES,
    NUMERIC_ESCAPE,
    enumerate_byte_code_tests,
    from_codes,
    is_legal_code,
    render_audit_text,
    render_provider_bytes,
    to_codes,
)


# ---------- 1. LEGAL_TEXT_CODES is exactly 62 codes ----------


def test_legal_text_codes_is_62_codes():
    """The legal alphabet is exactly 62 codes: 10 digits + 26 uppercase
    + 26 lowercase.
    """
    assert len(LEGAL_TEXT_CODES) == 62
    # The 10 digit codes.
    for c in range(0x30, 0x3A):
        assert c in LEGAL_TEXT_CODES
    # The 26 uppercase codes.
    for c in range(0x41, 0x5B):
        assert c in LEGAL_TEXT_CODES
    # The 26 lowercase codes.
    for c in range(0x61, 0x7B):
        assert c in LEGAL_TEXT_CODES
    # And one specific code that should NOT be in the set.
    assert 0x2C not in LEGAL_TEXT_CODES  # comma
    assert 0x21 not in LEGAL_TEXT_CODES  # exclamation
    assert 0x20 not in LEGAL_TEXT_CODES  # space


# ---------- 2. The 256-code sweep ----------


@pytest.mark.parametrize("code", enumerate_byte_code_tests())
def test_all_256_byte_codes(code):
    """The strict projection: legal codes pass, non-legal codes are
    escaped. The 256-byte space is covered by one parametrized test.
    (ADR-0017 generator pattern.)
    """
    rendered = from_codes([code], strict=True)
    if is_legal_code(code):
        assert rendered == chr(code)
    else:
        assert rendered == f"{NUMERIC_ESCAPE}0x{code:02X}"


# ---------- 3. Lossless roundtrip ----------


@pytest.mark.parametrize(
    "payload",
    [
        b"",
        b"A",
        b"a" * 16,
        b"Hello, world!",
        bytes(range(256)),  # all 256 byte codes
        b"sk-proj-abc_-",  # a real API key shape (contains `-` and `_`)
        b"\x00\x01\x02\xff" * 64,  # mixed non-ASCII
        b"x" * 4096,
        b"y" * 65536,
    ],
    ids=[
        "empty",
        "single_byte",
        "16x_a",
        "ascii_with_punct",
        "all_256_codes",
        "api_key_shape",
        "mixed_non_ascii",
        "4KB",
        "64KB",
    ],
)
def test_legal_roundtrip_lossless(payload):
    """`from_codes(to_codes(x), strict=False) == x` for arbitrary bytes.

    The provider boundary uses `strict=False` and reconstructs the
    exact original bytes. The storage layer is lossless.
    """
    codes = to_codes(payload)
    assert len(codes) == len(payload)
    # Roundtrip via the provider-boundary path.
    reconstructed = from_codes(codes, strict=False)
    assert reconstructed == payload


# ---------- 4. Render-strict replaces non-legal bytes with escape tokens ----------


def test_render_strict_replaces_non_legal_with_escape():
    """The strict projection replaces non-legal bytes with `#0xNN`."""
    # Comma (0x2C), space (0x20), exclamation (0x21) are non-legal.
    rendered = render_audit_text(b"a, b!c")
    assert rendered == "a#0x2C#0x20b#0x21c"
    # And the strict=False path reconstructs exactly.
    assert render_provider_bytes(b"a, b!c") == b"a, b!c"


# ---------- 5. Audit emit uses strict=True (the audit-render filter) ----------


def test_audit_emit_uses_strict_true():
    """A payload with non-ASCII bytes renders as the strict
    projection in the audit log. The in-memory payload is unchanged.
    """
    # A non-ASCII byte: 0xC3 0xA9 = UTF-8 for é.
    payload_bytes = b"caf\xc3\xa9"
    audit_text = render_audit_text(payload_bytes)
    # é is not in the 62 codes; renders as #0xC3#0xA9.
    assert "caf" in audit_text
    assert "#0xC3" in audit_text
    assert "#0xA9" in audit_text
    # But the provider boundary reconstructs the exact bytes.
    assert render_provider_bytes(payload_bytes) == payload_bytes


# ---------- 6. Provider boundary uses strict=False (lossless) ----------


def test_provider_boundary_uses_strict_false():
    """The provider-boundary call reconstructs the exact original
    bytes. A secret like `sk-proj-abc_-` round-trips bit-for-bit.
    """
    secret = b"sk-proj-abc_-"
    # Strict projection: every `-` is 0x2D, every `_` is 0x5F.
    # The secret is s-k-(-)-p-r-o-j-(-)-a-b-c-(_)-(-) so the audit
    # text is sk#0x2Dproj#0x2Dabc#0x5F#0x2D.
    assert render_audit_text(secret) == "sk#0x2Dproj#0x2Dabc#0x5F#0x2D"
    # Provider boundary: exact bytes.
    assert render_provider_bytes(secret) == secret
    # str input is encoded to UTF-8 first (lossless for ASCII).
    assert render_provider_bytes("hello") == b"hello"


# ---------- Bonus: to_codes rejects non-bytes ----------


def test_to_codes_rejects_non_bytes():
    """`to_codes` requires bytes or bytearray."""
    with pytest.raises(TypeError):
        to_codes("not bytes")  # type: ignore[arg-type]
