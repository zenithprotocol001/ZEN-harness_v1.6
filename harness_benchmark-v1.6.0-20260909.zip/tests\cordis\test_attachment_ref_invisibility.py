"""Attachment refs are invisible to `key_lookup` (ADR-0020).

The v1.5.0 attachment service stores its v0x04 envelope under
the name `attachment:{session_id}:{uuid}`. The LLM-provider key
lookup (`dhc.integrations.key_lookup`) only ever queries
`llm_provider_*` names, so an `attachment:` name is not part of
the namespace it walks.

This test asserts the property positively: a secrets service
populated with an `attachment:*` value (a hostile or buggy
caller trying to surface attachments as API keys) does NOT
cause `lookup_api_key` to return that value. The function
returns `None` for the `(provider, model_id)` pair.
"""
from __future__ import annotations

from dhc.integrations.key_lookup import lookup_api_key


def test_attachment_ref_is_invisible_to_key_lookup() -> None:
    """`lookup_api_key` ignores `attachment:*` names."""
    # A secrets service whose only entry is an attachment ref.
    store: dict[str, str] = {
        "attachment:s_abc:00000000000000000000000000000000": "NOT-AN-API-KEY",
    }
    result = lookup_api_key(
        provider="openai",
        model_id="gpt-4o-mini",
        secrets_service=store.get,
    )
    assert result is None


def test_lookup_api_key_never_constructs_attachment_names() -> None:
    """`lookup_api_key` only constructs `llm_provider_*` names.

    The function calls `secrets_service(name)` for the canonical,
    `___N`, and fallback names. The names it constructs all start
    with `llm_provider_`. A secrets service that records every
    `get` call would only see those prefixes, never `attachment:`.
    """
    called: list[str] = []

    def tracker(name: str) -> str | None:
        called.append(name)
        return None

    lookup_api_key(
        provider="anthropic",
        model_id="claude-3-5-sonnet-latest",
        secrets_service=tracker,
        provider_first_model_id="anthropic/claude-3-5-sonnet-latest",
    )
    assert called, "lookup_api_key should call the secrets service"
    for name in called:
        assert name.startswith("llm_provider_"), (
            f"lookup_api_key constructed non-llm_provider_ name: {name!r}"
        )
        assert not name.startswith("attachment:"), (
            f"lookup_api_key constructed an attachment: name: {name!r}"
        )
